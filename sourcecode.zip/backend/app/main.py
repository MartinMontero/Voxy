"""
Voxy Backend - AI-Powered Podcast Generation Platform
Built entirely through AI-driven development using Anthropic Claude
"""

from fastapi import FastAPI, Request, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from fastapi.responses import JSONResponse
import structlog
import time
from contextlib import asynccontextmanager

from app.core.config import settings
from app.core.security import SecurityMiddleware
from app.core.database import engine, Base
from app.routers import auth, projects, documents, audio, personas, mozilla, privacy
from app.services.mozilla_integration import MozillaServiceOrchestrator
from app.services.openai_blocker import OpenAIBlocker

# Configure structured logging
structlog.configure(
    processors=[
        structlog.stdlib.filter_by_level,
        structlog.stdlib.add_logger_name,
        structlog.stdlib.add_log_level,
        structlog.stdlib.PositionalArgumentsFormatter(),
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
        structlog.processors.UnicodeDecoder(),
        structlog.processors.JSONRenderer()
    ],
    context_class=dict,
    logger_factory=structlog.stdlib.LoggerFactory(),
    cache_logger_on_first_use=True,
)

logger = structlog.get_logger()

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan management"""
    logger.info("Starting Voxy backend server")
    
    # Initialize Mozilla services
    mozilla_orchestrator = MozillaServiceOrchestrator()
    await mozilla_orchestrator.initialize()
    app.state.mozilla = mozilla_orchestrator
    
    # Initialize OpenAI blocker
    openai_blocker = OpenAIBlocker()
    app.state.openai_blocker = openai_blocker
    
    # Create database tables
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    
    logger.info("Voxy backend initialized successfully")
    yield
    
    logger.info("Shutting down Voxy backend")

# Create FastAPI application
app = FastAPI(
    title="Voxy API",
    description="AI-Powered Podcast Generation Platform - Built with Anthropic Claude & Mozilla Technologies",
    version="1.0.0",
    docs_url="/api/docs" if settings.ENVIRONMENT == "development" else None,
    redoc_url="/api/redoc" if settings.ENVIRONMENT == "development" else None,
    lifespan=lifespan
)

# Security Middleware
app.add_middleware(SecurityMiddleware)

# CORS Middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE", "PATCH"],
    allow_headers=["*"],
)

# Trusted Host Middleware
if settings.ENVIRONMENT == "production":
    app.add_middleware(
        TrustedHostMiddleware,
        allowed_hosts=settings.ALLOWED_HOSTS
    )

# Request logging middleware
@app.middleware("http")
async def log_requests(request: Request, call_next):
    start_time = time.time()
    
    # Log request
    logger.info(
        "Request started",
        method=request.method,
        url=str(request.url),
        client_ip=request.client.host if request.client else None
    )
    
    response = await call_next(request)
    
    # Log response
    process_time = time.time() - start_time
    logger.info(
        "Request completed",
        method=request.method,
        url=str(request.url),
        status_code=response.status_code,
        process_time=round(process_time, 4)
    )
    
    return response

# Exception handlers
@app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException):
    logger.error(
        "HTTP exception occurred",
        status_code=exc.status_code,
        detail=exc.detail,
        url=str(request.url)
    )
    return JSONResponse(
        status_code=exc.status_code,
        content={"detail": exc.detail, "type": "http_exception"}
    )

@app.exception_handler(Exception)
async def general_exception_handler(request: Request, exc: Exception):
    logger.error(
        "Unexpected exception occurred",
        exception=str(exc),
        url=str(request.url),
        exc_info=True
    )
    return JSONResponse(
        status_code=500,
        content={"detail": "Internal server error", "type": "server_error"}
    )

# Health check endpoint
@app.get("/health")
async def health_check():
    """Health check endpoint for load balancers"""
    return {
        "status": "healthy",
        "service": "voxy-backend",
        "version": "1.0.0",
        "ai_services": {
            "anthropic": "enabled",
            "mozilla_deepspeech": "enabled",
            "mozilla_tts": "enabled",
            "openai_blocked": True
        }
    }

# API Routes
app.include_router(auth.router, prefix="/api/auth", tags=["Authentication"])
app.include_router(projects.router, prefix="/api/projects", tags=["Projects"])
app.include_router(documents.router, prefix="/api/documents", tags=["Documents"])
app.include_router(audio.router, prefix="/api/audio", tags=["Audio Generation"])
app.include_router(personas.router, prefix="/api/personas", tags=["Personas"])
app.include_router(mozilla.router, prefix="/api/mozilla", tags=["Mozilla Services"])
app.include_router(privacy.router, prefix="/api/privacy", tags=["Privacy Controls"])

# Root endpoint
@app.get("/")
async def root():
    """Root endpoint with API information"""
    return {
        "message": "Voxy API - AI-Powered Podcast Generation Platform",
        "description": "Built entirely through AI-driven development",
        "technologies": {
            "ai_language": "Anthropic Claude (Exclusive)",
            "speech_recognition": "Mozilla DeepSpeech",
            "speech_synthesis": "Mozilla TTS",
            "voice_dataset": "Mozilla Common Voice",
            "blocked_services": ["OpenAI GPT", "ChatGPT", "Whisper", "DALL-E"]
        },
        "privacy": "Privacy-first design with local processing options",
        "documentation": "/api/docs" if settings.ENVIRONMENT == "development" else "Contact support",
        "version": "1.0.0"
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "app.main:app",
        host="0.0.0.0",
        port=8000,
        reload=settings.ENVIRONMENT == "development",
        log_config=None  # Use structlog instead
    )