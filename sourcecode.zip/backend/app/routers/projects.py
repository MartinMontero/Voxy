"""
Project management API endpoints for Voxy
"""

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, delete
from typing import List
import structlog
from uuid import UUID

from app.core.database import get_db, Project, User
from app.core.security import get_current_user
from app.models.schemas import (
    ProjectCreate, ProjectUpdate, ProjectResponse, 
    GenerationSettings, ProjectListResponse
)
from app.services.anthropic_service import AnthropicService
from app.services.mozilla_integration import MozillaServiceOrchestrator

logger = structlog.get_logger()
router = APIRouter()

@router.post("/", response_model=ProjectResponse)
async def create_project(
    project_data: ProjectCreate,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Create a new podcast project"""
    
    try:
        # Create project
        project = Project(
            user_id=current_user["user_id"],
            name=project_data.name,
            description=project_data.description,
            processing_mode=project_data.processing_mode,
            privacy_level=project_data.privacy_level,
            generation_settings=project_data.generation_settings.dict() if project_data.generation_settings else {}
        )
        
        db.add(project)
        await db.commit()
        await db.refresh(project)
        
        logger.info(
            "Project created",
            project_id=str(project.id),
            user_id=current_user["user_id"],
            processing_mode=project.processing_mode
        )
        
        return ProjectResponse.from_orm(project)
        
    except Exception as e:
        logger.error("Failed to create project", error=str(e), exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to create project"
        )

@router.get("/", response_model=ProjectListResponse)
async def list_projects(
    skip: int = 0,
    limit: int = 20,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """List user's projects"""
    
    try:
        # Query projects
        query = select(Project).where(
            Project.user_id == current_user["user_id"]
        ).offset(skip).limit(limit).order_by(Project.updated_at.desc())
        
        result = await db.execute(query)
        projects = result.scalars().all()
        
        # Count total
        count_query = select(Project).where(Project.user_id == current_user["user_id"])
        count_result = await db.execute(count_query)
        total = len(count_result.scalars().all())
        
        return ProjectListResponse(
            projects=[ProjectResponse.from_orm(p) for p in projects],
            total=total,
            skip=skip,
            limit=limit
        )
        
    except Exception as e:
        logger.error("Failed to list projects", error=str(e), exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to list projects"
        )

@router.get("/{project_id}", response_model=ProjectResponse)
async def get_project(
    project_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Get project by ID"""
    
    try:
        query = select(Project).where(
            Project.id == project_id,
            Project.user_id == current_user["user_id"]
        )
        
        result = await db.execute(query)
        project = result.scalar_one_or_none()
        
        if not project:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Project not found"
            )
        
        return ProjectResponse.from_orm(project)
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error("Failed to get project", error=str(e), exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get project"
        )

@router.put("/{project_id}", response_model=ProjectResponse)
async def update_project(
    project_id: UUID,
    project_data: ProjectUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Update project"""
    
    try:
        query = select(Project).where(
            Project.id == project_id,
            Project.user_id == current_user["user_id"]
        )
        
        result = await db.execute(query)
        project = result.scalar_one_or_none()
        
        if not project:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Project not found"
            )
        
        # Update fields
        update_data = project_data.dict(exclude_unset=True)
        for field, value in update_data.items():
            if hasattr(project, field):
                setattr(project, field, value)
        
        await db.commit()
        await db.refresh(project)
        
        logger.info("Project updated", project_id=str(project.id))
        
        return ProjectResponse.from_orm(project)
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error("Failed to update project", error=str(e), exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to update project"
        )

@router.delete("/{project_id}")
async def delete_project(
    project_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Delete project"""
    
    try:
        query = select(Project).where(
            Project.id == project_id,
            Project.user_id == current_user["user_id"]
        )
        
        result = await db.execute(query)
        project = result.scalar_one_or_none()
        
        if not project:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Project not found"
            )
        
        # Delete project (cascades to documents)
        await db.delete(project)
        await db.commit()
        
        logger.info("Project deleted", project_id=str(project.id))
        
        return {"message": "Project deleted successfully"}
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error("Failed to delete project", error=str(e), exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to delete project"
        )

@router.post("/{project_id}/generate")
async def generate_podcast(
    project_id: UUID,
    generation_settings: GenerationSettings,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Generate podcast for project"""
    
    try:
        # Get project
        query = select(Project).where(
            Project.id == project_id,
            Project.user_id == current_user["user_id"]
        )
        
        result = await db.execute(query)
        project = result.scalar_one_or_none()
        
        if not project:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Project not found"
            )
        
        # Check if project has documents
        if not project.documents:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Project must have documents before generating podcast"
            )
        
        # Update project status
        project.status = "generating"
        project.generation_progress = 0
        project.generation_settings = generation_settings.dict()
        await db.commit()
        
        # Start generation process (this would typically be a background task)
        logger.info(
            "Starting podcast generation",
            project_id=str(project.id),
            processing_mode=project.processing_mode
        )
        
        # For demo purposes, return immediately
        # In production, this would trigger a Celery task
        return {
            "message": "Podcast generation started",
            "project_id": str(project.id),
            "status": "generating"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error("Failed to start generation", error=str(e), exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to start podcast generation"
        )