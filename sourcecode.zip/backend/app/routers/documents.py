"""
Document management API endpoints for Voxy
"""

from fastapi import APIRouter, Depends, HTTPException, status, UploadFile, File
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from typing import List
import structlog
import aiofiles
import hashlib
from pathlib import Path
from uuid import UUID
import magic

from app.core.database import get_db, Document, Project
from app.core.security import get_current_user
from app.core.config import settings
from app.models.schemas import DocumentResponse, FileUploadResponse
from app.services.mozilla_integration import MozillaServiceOrchestrator

logger = structlog.get_logger()
router = APIRouter()

@router.post("/upload/{project_id}", response_model=FileUploadResponse)
async def upload_document(
    project_id: UUID,
    file: UploadFile = File(...),
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Upload document to project"""
    
    try:
        # Verify project ownership
        project_query = select(Project).where(
            Project.id == project_id,
            Project.user_id == current_user["user_id"]
        )
        project_result = await db.execute(project_query)
        project = project_result.scalar_one_or_none()
        
        if not project:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Project not found"
            )
        
        # Validate file
        if file.size > settings.MAX_FILE_SIZE:
            raise HTTPException(
                status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
                detail=f"File too large. Maximum size: {settings.MAX_FILE_SIZE} bytes"
            )
        
        # Read file content
        content = await file.read()
        
        # Detect file type
        file_type = magic.from_buffer(content, mime=True)
        
        if file_type not in settings.ALLOWED_FILE_TYPES:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"File type not allowed: {file_type}"
            )
        
        # Generate file hash for deduplication
        content_hash = hashlib.sha256(content).hexdigest()
        
        # Check for duplicate
        duplicate_query = select(Document).where(
            Document.project_id == project_id,
            Document.content_hash == content_hash
        )
        duplicate_result = await db.execute(duplicate_query)
        duplicate = duplicate_result.scalar_one_or_none()
        
        if duplicate:
            return FileUploadResponse(
                document_id=duplicate.id,
                filename=duplicate.filename,
                file_size=duplicate.file_size,
                status=duplicate.status,
                message="File already exists in project"
            )
        
        # Save file
        file_path = Path(settings.UPLOAD_DIR) / f"{project_id}" / f"{content_hash}_{file.filename}"
        file_path.parent.mkdir(parents=True, exist_ok=True)
        
        async with aiofiles.open(file_path, 'wb') as f:
            await f.write(content)
        
        # Create document record
        document = Document(
            project_id=project_id,
            filename=file.filename,
            original_filename=file.filename,
            file_type=file_type,
            file_size=file.size,
            file_path=str(file_path),
            content_hash=content_hash,
            is_audio=file_type.startswith('audio/'),
            status="uploading"
        )
        
        db.add(document)
        await db.commit()
        await db.refresh(document)
        
        logger.info(
            "Document uploaded",
            document_id=str(document.id),
            project_id=str(project_id),
            filename=file.filename,
            file_type=file_type,
            is_audio=document.is_audio
        )
        
        # Start processing (background task in production)
        # For now, just mark as processing
        document.status = "processing"
        await db.commit()
        
        return FileUploadResponse(
            document_id=document.id,
            filename=document.filename,
            file_size=document.file_size,
            status=document.status,
            message="File uploaded successfully"
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error("File upload failed", error=str(e), exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="File upload failed"
        )

@router.get("/{document_id}", response_model=DocumentResponse)
async def get_document(
    document_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Get document by ID"""
    
    try:
        # Query with project ownership check
        query = select(Document).join(Project).where(
            Document.id == document_id,
            Project.user_id == current_user["user_id"]
        )
        
        result = await db.execute(query)
        document = result.scalar_one_or_none()
        
        if not document:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Document not found"
            )
        
        return DocumentResponse.from_orm(document)
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error("Failed to get document", error=str(e), exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get document"
        )

@router.delete("/{document_id}")
async def delete_document(
    document_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Delete document"""
    
    try:
        # Query with project ownership check
        query = select(Document).join(Project).where(
            Document.id == document_id,
            Project.user_id == current_user["user_id"]
        )
        
        result = await db.execute(query)
        document = result.scalar_one_or_none()
        
        if not document:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Document not found"
            )
        
        # Delete file from storage
        try:
            file_path = Path(document.file_path)
            if file_path.exists():
                file_path.unlink()
        except Exception as e:
            logger.warning("Failed to delete file from storage", error=str(e))
        
        # Delete from database
        await db.delete(document)
        await db.commit()
        
        logger.info("Document deleted", document_id=str(document.id))
        
        return {"message": "Document deleted successfully"}
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error("Failed to delete document", error=str(e), exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to delete document"
        )

@router.get("/project/{project_id}", response_model=List[DocumentResponse])
async def list_project_documents(
    project_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """List documents in project"""
    
    try:
        # Verify project ownership
        project_query = select(Project).where(
            Project.id == project_id,
            Project.user_id == current_user["user_id"]
        )
        project_result = await db.execute(project_query)
        project = project_result.scalar_one_or_none()
        
        if not project:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Project not found"
            )
        
        # Get documents
        query = select(Document).where(
            Document.project_id == project_id
        ).order_by(Document.uploaded_at.desc())
        
        result = await db.execute(query)
        documents = result.scalars().all()
        
        return [DocumentResponse.from_orm(doc) for doc in documents]
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error("Failed to list documents", error=str(e), exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to list documents"
        )