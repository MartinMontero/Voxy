"""
Persona management API endpoints for Voxy
"""

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from typing import List
import structlog
from uuid import UUID

from app.core.database import get_db, Persona
from app.core.security import get_current_user
from app.models.schemas import PersonaCreate, PersonaResponse

logger = structlog.get_logger()
router = APIRouter()

@router.get("/", response_model=List[PersonaResponse])
async def list_personas(
    include_default: bool = True,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """List available personas"""
    
    try:
        query = select(Persona)
        
        if include_default:
            # Include default personas and user's custom personas
            query = query.where(
                (Persona.is_default == True) | 
                (Persona.user_id == current_user["user_id"])
            )
        else:
            # Only user's custom personas
            query = query.where(Persona.user_id == current_user["user_id"])
        
        query = query.order_by(Persona.is_default.desc(), Persona.usage_count.desc())
        
        result = await db.execute(query)
        personas = result.scalars().all()
        
        return [PersonaResponse.from_orm(persona) for persona in personas]
        
    except Exception as e:
        logger.error("Failed to list personas", error=str(e), exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to list personas"
        )

@router.post("/", response_model=PersonaResponse)
async def create_persona(
    persona_data: PersonaCreate,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Create custom persona"""
    
    try:
        persona = Persona(
            user_id=current_user["user_id"],
            name=persona_data.name,
            role=persona_data.role,
            personality=persona_data.personality,
            description=persona_data.description,
            voice_profile_id=persona_data.voice_profile_id,
            is_default=False
        )
        
        db.add(persona)
        await db.commit()
        await db.refresh(persona)
        
        logger.info(
            "Custom persona created",
            persona_id=str(persona.id),
            user_id=current_user["user_id"],
            name=persona.name
        )
        
        return PersonaResponse.from_orm(persona)
        
    except Exception as e:
        logger.error("Failed to create persona", error=str(e), exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to create persona"
        )

@router.get("/{persona_id}", response_model=PersonaResponse)
async def get_persona(
    persona_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Get persona by ID"""
    
    try:
        query = select(Persona).where(
            Persona.id == persona_id,
            (Persona.is_default == True) | (Persona.user_id == current_user["user_id"])
        )
        
        result = await db.execute(query)
        persona = result.scalar_one_or_none()
        
        if not persona:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Persona not found"
            )
        
        return PersonaResponse.from_orm(persona)
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error("Failed to get persona", error=str(e), exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get persona"
        )

@router.delete("/{persona_id}")
async def delete_persona(
    persona_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Delete custom persona"""
    
    try:
        query = select(Persona).where(
            Persona.id == persona_id,
            Persona.user_id == current_user["user_id"],
            Persona.is_default == False  # Can't delete default personas
        )
        
        result = await db.execute(query)
        persona = result.scalar_one_or_none()
        
        if not persona:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Persona not found or cannot be deleted"
            )
        
        await db.delete(persona)
        await db.commit()
        
        logger.info("Persona deleted", persona_id=str(persona.id))
        
        return {"message": "Persona deleted successfully"}
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error("Failed to delete persona", error=str(e), exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to delete persona"
        )