"""
Security middleware and utilities for Voxy backend
"""

from fastapi import Request, HTTPException
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import Response
from jose import JWTError, jwt
from passlib.context import CryptContext
from datetime import datetime, timedelta
from typing import Optional, Dict, Any
import structlog
import time
import asyncio
from collections import defaultdict

from app.core.config import settings

logger = structlog.get_logger()

# Password hashing
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# JWT token handling
security = HTTPBearer()

class SecurityMiddleware(BaseHTTPMiddleware):
    """Comprehensive security middleware for Voxy"""
    
    def __init__(self, app):
        super().__init__(app)
        self.blocked_domains = settings.BLOCKED_DOMAINS
        self.rate_limiter = defaultdict(list)
        
    async def dispatch(self, request: Request, call_next):
        start_time = time.time()
        
        try:
            # 1. OpenAI Blocking (Critical Security Feature)
            await self._block_openai_requests(request)
            
            # 2. Rate Limiting
            await self._apply_rate_limiting(request)
            
            # 3. Privacy Headers Validation
            await self._validate_privacy_headers(request)
            
            # 4. Security Headers
            response = await call_next(request)
            self._add_security_headers(response)
            
            return response
            
        except HTTPException:
            raise
        except Exception as e:
            logger.error("Security middleware error", error=str(e), exc_info=True)
            raise HTTPException(status_code=500, detail="Security validation failed")
    
    async def _block_openai_requests(self, request: Request):
        """Block any requests to OpenAI services (Critical Security Feature)"""
        
        # Check URL for OpenAI domains
        url_str = str(request.url).lower()
        for domain in self.blocked_domains:
            if domain in url_str:
                logger.critical(
                    "BLOCKED: OpenAI request attempt detected",
                    url=str(request.url),
                    client_ip=request.client.host if request.client else None,
                    user_agent=request.headers.get("user-agent")
                )
                raise HTTPException(
                    status_code=403, 
                    detail="OpenAI services are blocked by Voxy security policy"
                )
        
        # Check headers for OpenAI API keys
        auth_header = request.headers.get("authorization", "")
        if "sk-" in auth_header and "openai" in auth_header.lower():
            logger.critical("BLOCKED: OpenAI API key detected in request")
            raise HTTPException(
                status_code=403,
                detail="OpenAI API keys are not permitted"
            )
        
        # Check request body for OpenAI references (for POST requests)
        if request.method == "POST":
            # This is a simplified check - in production, you'd want more sophisticated detection
            content_type = request.headers.get("content-type", "")
            if "application/json" in content_type:
                # Note: In a real implementation, you'd need to carefully parse the body
                # without consuming it, which requires more complex middleware
                pass
    
    async def _apply_rate_limiting(self, request: Request):
        """Apply rate limiting per IP address"""
        client_ip = request.client.host if request.client else "unknown"
        current_time = time.time()
        
        # Clean old entries
        self.rate_limiter[client_ip] = [
            req_time for req_time in self.rate_limiter[client_ip]
            if current_time - req_time < 60  # 1 minute window
        ]
        
        # Check rate limit
        if len(self.rate_limiter[client_ip]) >= settings.RATE_LIMIT_PER_MINUTE:
            logger.warning(
                "Rate limit exceeded",
                client_ip=client_ip,
                requests_count=len(self.rate_limiter[client_ip])
            )
            raise HTTPException(
                status_code=429,
                detail="Rate limit exceeded. Please try again later."
            )
        
        # Add current request
        self.rate_limiter[client_ip].append(current_time)
    
    async def _validate_privacy_headers(self, request: Request):
        """Validate privacy-related headers"""
        privacy_mode = request.headers.get("X-Privacy-Mode")
        
        if privacy_mode == "maximum":
            # Ensure no external service calls for maximum privacy
            request.state.use_local_models = True
            request.state.block_external_calls = True
        elif privacy_mode == "balanced":
            # Allow Anthropic but prefer local for speech
            request.state.use_local_models = False
            request.state.prefer_local_speech = True
        
        # Log privacy preferences
        logger.info(
            "Privacy mode applied",
            privacy_mode=privacy_mode,
            use_local_models=getattr(request.state, 'use_local_models', False)
        )
    
    def _add_security_headers(self, response: Response):
        """Add security headers to response"""
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["X-XSS-Protection"] = "1; mode=block"
        response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
        response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        response.headers["Permissions-Policy"] = "geolocation=(), microphone=(), camera=()"
        
        # Voxy-specific headers
        response.headers["X-Voxy-Privacy"] = "enabled"
        response.headers["X-OpenAI-Blocked"] = "true"
        response.headers["X-Mozilla-Powered"] = "true"

class OpenAIBlocker:
    """Dedicated OpenAI blocking service"""
    
    def __init__(self):
        self.blocked_terms = [
            "openai", "gpt", "chatgpt", "dall-e", "whisper",
            "sk-", "org-", "azure-openai"
        ]
        self.blocked_domains = settings.BLOCKED_DOMAINS
    
    async def scan_request(self, request: Request) -> bool:
        """Scan request for OpenAI usage"""
        
        # Check URL
        url_lower = str(request.url).lower()
        for domain in self.blocked_domains:
            if domain in url_lower:
                return False
        
        # Check headers
        for header_name, header_value in request.headers.items():
            if any(term in header_value.lower() for term in self.blocked_terms):
                return False
        
        return True
    
    def validate_no_openai_dependencies(self) -> bool:
        """Validate that no OpenAI dependencies are present"""
        try:
            import openai
            logger.critical("SECURITY VIOLATION: OpenAI package detected")
            return False
        except ImportError:
            pass
        
        return True

# Authentication utilities
def create_access_token(data: Dict[str, Any], expires_delta: Optional[timedelta] = None) -> str:
    """Create JWT access token"""
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, settings.SECRET_KEY, algorithm="HS256")
    return encoded_jwt

def verify_token(token: str) -> Optional[Dict[str, Any]]:
    """Verify JWT token"""
    try:
        payload = jwt.decode(token, settings.SECRET_KEY, algorithms=["HS256"])
        return payload
    except JWTError:
        return None

def hash_password(password: str) -> str:
    """Hash password using bcrypt"""
    return pwd_context.hash(password)

def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Verify password against hash"""
    return pwd_context.verify(plain_password, hashed_password)

async def get_current_user(credentials: HTTPAuthorizationCredentials = security):
    """Get current authenticated user"""
    token = credentials.credentials
    payload = verify_token(token)
    
    if payload is None:
        raise HTTPException(
            status_code=401,
            detail="Could not validate credentials",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    return payload