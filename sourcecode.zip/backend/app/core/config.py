"""
Configuration settings for Voxy backend
"""

from pydantic_settings import BaseSettings
from typing import List, Optional
import os
from pathlib import Path

class Settings(BaseSettings):
    """Application settings with environment variable support"""
    
    # Application
    APP_NAME: str = "Voxy"
    ENVIRONMENT: str = "development"
    DEBUG: bool = True
    SECRET_KEY: str = "your-secret-key-change-in-production"
    
    # API Configuration
    API_V1_STR: str = "/api"
    ALLOWED_ORIGINS: List[str] = ["http://localhost:3000", "http://localhost:5173"]
    ALLOWED_HOSTS: List[str] = ["localhost", "127.0.0.1"]
    
    # Database
    DATABASE_URL: str = "postgresql+asyncpg://voxy:voxy@localhost:5432/voxy"
    DATABASE_POOL_SIZE: int = 10
    DATABASE_MAX_OVERFLOW: int = 20
    
    # Redis
    REDIS_URL: str = "redis://localhost:6379/0"
    
    # Anthropic AI (REQUIRED)
    ANTHROPIC_API_KEY: str = ""
    ANTHROPIC_MODEL: str = "claude-3-sonnet-20240229"
    ANTHROPIC_MAX_TOKENS: int = 4000
    
    # Mozilla Services
    MOZILLA_STT_MODEL_PATH: str = "/models/deepspeech"
    MOZILLA_TTS_MODEL_PATH: str = "/models/mozilla-tts"
    COMMON_VOICE_PATH: str = "/data/common-voice"
    ENABLE_VOICE_CONTRIBUTIONS: bool = True
    
    # Privacy Settings
    DEFAULT_PRIVACY_MODE: str = "balanced"
    ENABLE_LOCAL_PROCESSING: bool = True
    ENABLE_ANONYMOUS_MODE: bool = True
    
    # OpenAI Blocking (Always enabled)
    BLOCK_OPENAI: bool = True
    OPENAI_BLOCKER_STRICT: bool = True
    BLOCKED_DOMAINS: List[str] = [
        "api.openai.com",
        "openai.com",
        "chat.openai.com",
        "platform.openai.com"
    ]
    
    # Open-Source Models
    LLAMA_MODEL_PATH: str = "/models/llama2-7b"
    MISTRAL_MODEL_PATH: str = "/models/mistral-7b"
    ENABLE_LOCAL_LLM: bool = True
    
    # File Storage
    UPLOAD_DIR: str = "/tmp/voxy/uploads"
    MAX_FILE_SIZE: int = 50 * 1024 * 1024  # 50MB
    ALLOWED_FILE_TYPES: List[str] = [
        "application/pdf",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "text/plain",
        "text/markdown",
        "audio/mpeg",
        "audio/wav",
        "audio/mp4"
    ]
    
    # Audio Processing
    AUDIO_SAMPLE_RATE: int = 22050
    AUDIO_CHANNELS: int = 1
    MAX_AUDIO_DURATION: int = 1200  # 20 minutes
    
    # Generation Settings
    DEFAULT_GENERATION_TIMEOUT: int = 300  # 5 minutes
    MAX_CONCURRENT_GENERATIONS: int = 5
    
    # Security
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30
    REFRESH_TOKEN_EXPIRE_DAYS: int = 7
    PASSWORD_MIN_LENGTH: int = 8
    
    # Monitoring
    SENTRY_DSN: Optional[str] = None
    ENABLE_METRICS: bool = True
    LOG_LEVEL: str = "INFO"
    
    # Rate Limiting
    RATE_LIMIT_PER_MINUTE: int = 60
    RATE_LIMIT_BURST: int = 10
    
    class Config:
        env_file = ".env"
        case_sensitive = True

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        
        # Ensure upload directory exists
        Path(self.UPLOAD_DIR).mkdir(parents=True, exist_ok=True)
        
        # Validate required settings
        if not self.ANTHROPIC_API_KEY and self.ENVIRONMENT == "production":
            raise ValueError("ANTHROPIC_API_KEY is required for production")
        
        # Ensure OpenAI blocking is always enabled
        if not self.BLOCK_OPENAI:
            raise ValueError("OpenAI blocking cannot be disabled")

# Create settings instance
settings = Settings()