"""
Database configuration and models for Voxy
"""

from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine, async_sessionmaker
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import Column, String, DateTime, Boolean, Integer, Text, JSON, ForeignKey, Enum, LargeBinary
from sqlalchemy.dialects.postgresql import UUID, ARRAY
from sqlalchemy.orm import relationship
import uuid
from datetime import datetime
from typing import Optional, List, Dict, Any
import enum

from app.core.config import settings

# Create async engine
engine = create_async_engine(
    settings.DATABASE_URL,
    pool_size=settings.DATABASE_POOL_SIZE,
    max_overflow=settings.DATABASE_MAX_OVERFLOW,
    echo=settings.DEBUG
)

# Create session factory
async_session = async_sessionmaker(
    engine, 
    class_=AsyncSession, 
    expire_on_commit=False
)

# Base class for all models
Base = declarative_base()

# Enums
class ProcessingMode(str, enum.Enum):
    CLOUD = "cloud"
    LOCAL = "local"
    HYBRID = "hybrid"

class PrivacyLevel(str, enum.Enum):
    MAXIMUM = "maximum"
    BALANCED = "balanced"
    PERFORMANCE = "performance"

class DocumentStatus(str, enum.Enum):
    UPLOADING = "uploading"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"

class GenerationStatus(str, enum.Enum):
    PENDING = "pending"
    ANALYZING = "analyzing"
    GENERATING = "generating"
    SYNTHESIZING = "synthesizing"
    COMPLETED = "completed"
    FAILED = "failed"

# Database Models
class User(Base):
    """User model with privacy preferences"""
    __tablename__ = "users"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    email = Column(String, unique=True, index=True, nullable=False)
    password_hash = Column(String, nullable=False)
    full_name = Column(String)
    is_active = Column(Boolean, default=True)
    is_verified = Column(Boolean, default=False)
    
    # Privacy preferences
    privacy_preferences = Column(JSON, default={})
    default_processing_mode = Column(Enum(ProcessingMode), default=ProcessingMode.BALANCED)
    default_privacy_level = Column(Enum(PrivacyLevel), default=PrivacyLevel.BALANCED)
    
    # Mozilla Common Voice contribution
    mozilla_contributor = Column(Boolean, default=False)
    voice_contribution_consent = Column(Boolean, default=False)
    
    # Security
    blocked_services = Column(ARRAY(String), default=["openai", "gpt", "chatgpt", "dall-e"])
    last_login = Column(DateTime)
    failed_login_attempts = Column(Integer, default=0)
    
    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    projects = relationship("Project", back_populates="user", cascade="all, delete-orphan")
    voice_contributions = relationship("VoiceContribution", back_populates="user")

class Project(Base):
    """Project model for podcast generation"""
    __tablename__ = "projects"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)
    
    # Basic info
    name = Column(String, nullable=False)
    description = Column(Text)
    
    # Processing configuration
    processing_mode = Column(Enum(ProcessingMode), nullable=False)
    privacy_level = Column(Enum(PrivacyLevel), nullable=False)
    
    # Generation settings
    generation_settings = Column(JSON, default={})
    selected_personas = Column(JSON, default=[])
    
    # Generated content
    generated_audio_url = Column(String)
    transcript = Column(Text)
    citations = Column(JSON, default=[])
    generation_metadata = Column(JSON, default={})
    
    # Status tracking
    status = Column(Enum(GenerationStatus), default=GenerationStatus.PENDING)
    generation_progress = Column(Integer, default=0)
    error_message = Column(Text)
    
    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    generated_at = Column(DateTime)
    
    # Relationships
    user = relationship("User", back_populates="projects")
    documents = relationship("Document", back_populates="project", cascade="all, delete-orphan")

class Document(Base):
    """Document model for uploaded files"""
    __tablename__ = "documents"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    project_id = Column(UUID(as_uuid=True), ForeignKey("projects.id"), nullable=False)
    
    # File information
    filename = Column(String, nullable=False)
    original_filename = Column(String, nullable=False)
    file_type = Column(String, nullable=False)
    file_size = Column(Integer, nullable=False)
    file_path = Column(String, nullable=False)
    
    # Content
    extracted_text = Column(Text)
    content_hash = Column(String)  # SHA-256 hash for deduplication
    
    # Processing
    status = Column(Enum(DocumentStatus), default=DocumentStatus.UPLOADING)
    processing_metadata = Column(JSON, default={})
    error_message = Column(Text)
    
    # Mozilla DeepSpeech specific (for audio files)
    is_audio = Column(Boolean, default=False)
    audio_duration = Column(Integer)  # in seconds
    transcription_confidence = Column(Integer)  # 0-100
    language_detected = Column(String)
    
    # Timestamps
    uploaded_at = Column(DateTime, default=datetime.utcnow)
    processed_at = Column(DateTime)
    
    # Relationships
    project = relationship("Project", back_populates="documents")

class Persona(Base):
    """AI persona model for conversation generation"""
    __tablename__ = "personas"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)  # NULL for default personas
    
    # Persona information
    name = Column(String, nullable=False)
    role = Column(String, nullable=False)
    personality = Column(Text, nullable=False)
    description = Column(Text, nullable=False)
    
    # Voice configuration
    voice_profile_id = Column(String)  # Common Voice profile ID
    voice_gender = Column(String)
    voice_language = Column(String, default="en-US")
    voice_accent = Column(String)
    
    # Usage and quality
    is_default = Column(Boolean, default=False)
    usage_count = Column(Integer, default=0)
    average_rating = Column(Integer, default=0)  # 1-5 stars
    
    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class VoiceContribution(Base):
    """Mozilla Common Voice contributions"""
    __tablename__ = "voice_contributions"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)
    
    # Audio data (privacy-preserving)
    audio_hash = Column(String, nullable=False)  # SHA-256 hash, not actual audio
    transcript = Column(Text, nullable=False)
    language = Column(String, nullable=False)
    
    # Privacy and consent
    consent_timestamp = Column(DateTime, nullable=False)
    anonymized = Column(Boolean, default=True)
    consent_version = Column(String, default="1.0")
    
    # Quality metrics
    duration_seconds = Column(Integer)
    quality_score = Column(Integer)  # 1-100
    validation_count = Column(Integer, default=0)
    
    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    user = relationship("User", back_populates="voice_contributions")

class GenerationJob(Base):
    """Background job tracking for podcast generation"""
    __tablename__ = "generation_jobs"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    project_id = Column(UUID(as_uuid=True), ForeignKey("projects.id"), nullable=False)
    
    # Job information
    job_type = Column(String, nullable=False)  # "podcast_generation", "document_processing", etc.
    status = Column(Enum(GenerationStatus), default=GenerationStatus.PENDING)
    progress = Column(Integer, default=0)
    
    # Processing details
    processing_mode = Column(Enum(ProcessingMode), nullable=False)
    ai_services_used = Column(JSON, default=[])
    
    # Results
    result_data = Column(JSON)
    error_message = Column(Text)
    
    # Performance metrics
    started_at = Column(DateTime)
    completed_at = Column(DateTime)
    processing_time_seconds = Column(Integer)
    
    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class AuditLog(Base):
    """Audit log for security and privacy tracking"""
    __tablename__ = "audit_logs"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    
    # Event information
    event_type = Column(String, nullable=False)  # "login", "generation", "privacy_change", etc.
    event_description = Column(Text)
    
    # Privacy tracking
    privacy_mode = Column(String)
    data_processed_locally = Column(Boolean)
    external_services_used = Column(JSON, default=[])
    
    # Security
    ip_address = Column(String)
    user_agent = Column(String)
    
    # Timestamps
    timestamp = Column(DateTime, default=datetime.utcnow)

# Database dependency
async def get_db() -> AsyncSession:
    """Get database session"""
    async with async_session() as session:
        try:
            yield session
        finally:
            await session.close()