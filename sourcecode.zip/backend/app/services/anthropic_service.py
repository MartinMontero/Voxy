"""
Anthropic Claude AI service integration for Voxy
Exclusive AI provider - No OpenAI allowed
"""

import anthropic
from typing import List, Dict, Any, Optional
import structlog
import json
import asyncio
from datetime import datetime

from app.core.config import settings
from app.models.schemas import Persona, Document, GenerationSettings, DialogueSegment, Citation

logger = structlog.get_logger()

class AnthropicService:
    """Anthropic Claude AI service for ethical conversation generation"""
    
    def __init__(self):
        if not settings.ANTHROPIC_API_KEY:
            raise ValueError("ANTHROPIC_API_KEY is required")
            
        self.client = anthropic.Anthropic(api_key=settings.ANTHROPIC_API_KEY)
        self.model = settings.ANTHROPIC_MODEL
        self.max_tokens = settings.ANTHROPIC_MAX_TOKENS
        
        # Constitutional AI safety classifier
        self.safety_classifier = SafetyClassifier()
        
        # Validate no OpenAI dependencies
        self._validate_no_openai()
    
    def _validate_no_openai(self):
        """Ensure no OpenAI dependencies are present"""
        try:
            import openai
            raise RuntimeError("SECURITY VIOLATION: OpenAI package detected in environment")
        except ImportError:
            logger.info("OpenAI blocking verified - no OpenAI packages found")
    
    async def generate_conversation(
        self,
        documents: List[Document],
        personas: List[Persona],
        settings_obj: GenerationSettings
    ) -> Dict[str, Any]:
        """Generate podcast conversation using Anthropic Claude"""
        
        logger.info(
            "Starting conversation generation",
            document_count=len(documents),
            persona_count=len(personas),
            duration=settings_obj.duration,
            tone=settings_obj.tone
        )
        
        try:
            # Step 1: Analyze documents and extract key insights
            document_analysis = await self._analyze_documents(documents)
            
            # Step 2: Generate conversation outline
            outline = await self._generate_outline(
                document_analysis, 
                personas, 
                settings_obj
            )
            
            # Step 3: Generate detailed dialogue
            dialogue = await self._generate_dialogue(outline, personas, settings_obj)
            
            # Step 4: Extract citations and verify accuracy
            citations = await self._extract_citations(dialogue, documents)
            
            # Step 5: Safety and quality checks
            safety_check = await self.safety_classifier.check(dialogue)
            if not safety_check.passed:
                dialogue = await self._regenerate_safe(dialogue, safety_check)
            
            # Step 6: Format final output
            result = {
                "dialogue_segments": dialogue,
                "citations": citations,
                "metadata": {
                    "generation_time": datetime.utcnow().isoformat(),
                    "model_used": self.model,
                    "safety_verified": True,
                    "document_sources": len(documents),
                    "total_segments": len(dialogue)
                }
            }
            
            logger.info(
                "Conversation generation completed",
                segments_generated=len(dialogue),
                citations_found=len(citations)
            )
            
            return result
            
        except Exception as e:
            logger.error("Conversation generation failed", error=str(e), exc_info=True)
            raise
    
    async def _analyze_documents(self, documents: List[Document]) -> Dict[str, Any]:
        """Analyze documents to extract key insights and themes"""
        
        # Combine all document content
        combined_content = "\n\n".join([
            f"Document: {doc.filename}\n{doc.extracted_text[:5000]}"  # Limit per doc
            for doc in documents
        ])
        
        analysis_prompt = f"""
        Analyze the following documents and extract key insights for podcast conversation generation.
        
        Documents:
        {combined_content}
        
        Please provide:
        1. Main themes and topics
        2. Key facts and statistics
        3. Interesting insights or surprising findings
        4. Potential discussion points
        5. Areas that might benefit from different perspectives
        
        Format your response as structured JSON with clear categories.
        """
        
        try:
            message = await self.client.messages.create(
                model=self.model,
                max_tokens=self.max_tokens,
                messages=[{
                    "role": "user",
                    "content": analysis_prompt
                }]
            )
            
            # Parse the response
            analysis_text = message.content[0].text
            
            # Try to extract JSON, fallback to structured text
            try:
                analysis = json.loads(analysis_text)
            except json.JSONDecodeError:
                analysis = {"raw_analysis": analysis_text}
            
            return analysis
            
        except Exception as e:
            logger.error("Document analysis failed", error=str(e))
            raise
    
    async def _generate_outline(
        self, 
        analysis: Dict[str, Any], 
        personas: List[Persona], 
        settings_obj: GenerationSettings
    ) -> Dict[str, Any]:
        """Generate conversation outline with natural flow"""
        
        persona_descriptions = "\n".join([
            f"- {p.name} ({p.role}): {p.personality}"
            for p in personas
        ])
        
        outline_prompt = f"""
        Create a detailed conversation outline for a {settings_obj.duration}-minute podcast.
        
        Tone: {settings_obj.tone}
        Language: {settings_obj.language}
        
        Participants:
        {persona_descriptions}
        
        Document Analysis:
        {json.dumps(analysis, indent=2)}
        
        Requirements:
        1. Natural conversation flow with smooth transitions
        2. Each persona should speak in character
        3. Include introduction{' and conclusion' if settings_obj.include_intro else ''}
        4. Incorporate specific facts and citations from documents
        5. Encourage different perspectives and healthy discussion
        6. Maintain engagement throughout
        
        Provide a structured outline with:
        - Introduction segment
        - 3-5 main discussion segments
        - Natural transition points
        - Conclusion segment
        - Estimated timing for each segment
        """
        
        try:
            message = await self.client.messages.create(
                model=self.model,
                max_tokens=self.max_tokens,
                messages=[{
                    "role": "user",
                    "content": outline_prompt
                }]
            )
            
            outline_text = message.content[0].text
            
            try:
                outline = json.loads(outline_text)
            except json.JSONDecodeError:
                outline = {"raw_outline": outline_text}
            
            return outline
            
        except Exception as e:
            logger.error("Outline generation failed", error=str(e))
            raise
    
    async def _generate_dialogue(
        self, 
        outline: Dict[str, Any], 
        personas: List[Persona], 
        settings_obj: GenerationSettings
    ) -> List[DialogueSegment]:
        """Generate detailed dialogue based on outline"""
        
        persona_descriptions = "\n".join([
            f"- {p.name} ({p.role}): {p.personality}\n  Speaking style: {p.description}"
            for p in personas
        ])
        
        dialogue_prompt = f"""
        Generate natural, engaging dialogue for a podcast conversation.
        
        Outline:
        {json.dumps(outline, indent=2)}
        
        Characters:
        {persona_descriptions}
        
        Guidelines:
        1. Each character must speak in their unique voice and style
        2. Include natural conversation elements (agreements, questions, clarifications)
        3. Reference specific facts from the source documents
        4. Maintain the {settings_obj.tone} tone throughout
        5. Create smooth transitions between topics
        6. Include natural pauses and reactions
        
        Format as JSON array with objects containing:
        - speaker: character name
        - text: what they say
        - timestamp: estimated time in seconds
        - citations: array of source references if applicable
        
        Generate approximately {settings_obj.duration * 150} words total (150 words per minute).
        """
        
        try:
            message = await self.client.messages.create(
                model=self.model,
                max_tokens=self.max_tokens,
                messages=[{
                    "role": "user",
                    "content": dialogue_prompt
                }]
            )
            
            dialogue_text = message.content[0].text
            
            # Extract JSON from response
            try:
                # Try to find JSON in the response
                start_idx = dialogue_text.find('[')
                end_idx = dialogue_text.rfind(']') + 1
                if start_idx != -1 and end_idx != 0:
                    json_str = dialogue_text[start_idx:end_idx]
                    dialogue_data = json.loads(json_str)
                else:
                    raise json.JSONDecodeError("No JSON array found", dialogue_text, 0)
            except json.JSONDecodeError:
                # Fallback: create structured dialogue from text
                dialogue_data = self._parse_dialogue_fallback(dialogue_text, personas)
            
            # Convert to DialogueSegment objects
            dialogue_segments = []
            for i, segment in enumerate(dialogue_data):
                dialogue_segments.append(DialogueSegment(
                    id=f"segment_{i}",
                    speaker=segment.get("speaker", personas[i % len(personas)].name),
                    text=segment.get("text", ""),
                    timestamp=segment.get("timestamp", i * 30),  # Default 30s intervals
                    citations=segment.get("citations", [])
                ))
            
            return dialogue_segments
            
        except Exception as e:
            logger.error("Dialogue generation failed", error=str(e))
            raise
    
    def _parse_dialogue_fallback(self, text: str, personas: List[Persona]) -> List[Dict[str, Any]]:
        """Fallback parser for dialogue text"""
        lines = text.split('\n')
        dialogue = []
        current_speaker = None
        current_text = ""
        timestamp = 0
        
        for line in lines:
            line = line.strip()
            if not line:
                continue
                
            # Check if line starts with a persona name
            speaker_found = False
            for persona in personas:
                if line.startswith(persona.name + ":"):
                    if current_speaker and current_text:
                        dialogue.append({
                            "speaker": current_speaker,
                            "text": current_text.strip(),
                            "timestamp": timestamp,
                            "citations": []
                        })
                        timestamp += 30
                    
                    current_speaker = persona.name
                    current_text = line[len(persona.name) + 1:].strip()
                    speaker_found = True
                    break
            
            if not speaker_found and current_speaker:
                current_text += " " + line
        
        # Add final segment
        if current_speaker and current_text:
            dialogue.append({
                "speaker": current_speaker,
                "text": current_text.strip(),
                "timestamp": timestamp,
                "citations": []
            })
        
        return dialogue
    
    async def _extract_citations(
        self, 
        dialogue: List[DialogueSegment], 
        documents: List[Document]
    ) -> List[Citation]:
        """Extract and verify citations from dialogue"""
        
        citations = []
        
        for segment in dialogue:
            if not segment.text:
                continue
                
            # Use Claude to identify claims that need citations
            citation_prompt = f"""
            Analyze this dialogue segment and identify any factual claims that should be cited:
            
            Speaker: {segment.speaker}
            Text: {segment.text}
            
            Available sources:
            {chr(10).join([f"- {doc.filename}" for doc in documents])}
            
            For each factual claim, provide:
            1. The specific claim text
            2. Which source document it likely came from
            3. Confidence level (1-10)
            
            Format as JSON array.
            """
            
            try:
                message = await self.client.messages.create(
                    model=self.model,
                    max_tokens=1000,
                    messages=[{
                        "role": "user",
                        "content": citation_prompt
                    }]
                )
                
                citation_text = message.content[0].text
                
                # Parse citations and add to list
                try:
                    citation_data = json.loads(citation_text)
                    for i, cite in enumerate(citation_data):
                        citations.append(Citation(
                            id=f"cite_{len(citations)}_{i}",
                            text=cite.get("claim", ""),
                            source=cite.get("source", "Unknown"),
                            timestamp=segment.timestamp,
                            confidence=cite.get("confidence", 5)
                        ))
                except json.JSONDecodeError:
                    pass  # Skip if parsing fails
                    
            except Exception as e:
                logger.warning("Citation extraction failed for segment", error=str(e))
                continue
        
        return citations
    
    async def _regenerate_safe(
        self, 
        dialogue: List[DialogueSegment], 
        safety_check: Dict[str, Any]
    ) -> List[DialogueSegment]:
        """Regenerate dialogue to address safety concerns"""
        
        logger.warning("Regenerating dialogue due to safety concerns", issues=safety_check.get("issues", []))
        
        # For now, return original dialogue with warning
        # In production, implement actual regeneration logic
        return dialogue

class SafetyClassifier:
    """Constitutional AI safety classifier"""
    
    def __init__(self):
        self.safety_rules = [
            "No harmful or offensive content",
            "Factual accuracy required",
            "Respectful discussion of all topics",
            "No promotion of dangerous activities",
            "Balanced perspectives on controversial topics"
        ]
    
    async def check(self, dialogue: List[DialogueSegment]) -> Dict[str, Any]:
        """Check dialogue against safety rules"""
        
        # Simple safety check - in production, use more sophisticated methods
        issues = []
        
        for segment in dialogue:
            text_lower = segment.text.lower()
            
            # Basic checks
            if any(word in text_lower for word in ["hate", "violence", "dangerous"]):
                issues.append(f"Potentially harmful content in segment by {segment.speaker}")
        
        return {
            "passed": len(issues) == 0,
            "issues": issues,
            "confidence": 0.9 if len(issues) == 0 else 0.3
        }