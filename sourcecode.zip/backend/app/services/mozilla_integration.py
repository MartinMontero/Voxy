"""
Mozilla DeepSpeech and TTS integration for Voxy
Privacy-first speech technologies
"""

import deepspeech
import numpy as np
import wave
import asyncio
import aiofiles
from pathlib import Path
from typing import Optional, Dict, Any, List
import structlog
import json
import subprocess
import tempfile
import os
from pydub import AudioSegment
import librosa

from app.core.config import settings
from app.models.schemas import VoiceProfile, TranscriptionResult, GeneratedAudio

logger = structlog.get_logger()

class MozillaDeepSpeechProcessor:
    """Mozilla DeepSpeech integration for privacy-first speech recognition"""
    
    def __init__(self):
        self.model_path = settings.MOZILLA_STT_MODEL_PATH + "/deepspeech-0.9.3-models.pbmm"
        self.scorer_path = settings.MOZILLA_STT_MODEL_PATH + "/deepspeech-0.9.3-models.scorer"
        self.model = None
        self.initialized = False
    
    async def initialize(self):
        """Initialize DeepSpeech model"""
        try:
            logger.info("Initializing Mozilla DeepSpeech", model_path=self.model_path)
            
            # Check if model files exist
            if not Path(self.model_path).exists():
                logger.warning("DeepSpeech model not found, downloading...")
                await self._download_models()
            
            # Load model
            self.model = deepspeech.Model(self.model_path)
            
            # Enable external scorer if available
            if Path(self.scorer_path).exists():
                self.model.enableExternalScorer(self.scorer_path)
                logger.info("External scorer enabled")
            
            self.initialized = True
            logger.info("Mozilla DeepSpeech initialized successfully")
            
        except Exception as e:
            logger.error("Failed to initialize DeepSpeech", error=str(e))
            raise
    
    async def _download_models(self):
        """Download DeepSpeech models if not present"""
        model_dir = Path(settings.MOZILLA_STT_MODEL_PATH)
        model_dir.mkdir(parents=True, exist_ok=True)
        
        # URLs for DeepSpeech models
        model_urls = {
            "deepspeech-0.9.3-models.pbmm": "https://github.com/mozilla/DeepSpeech/releases/download/v0.9.3/deepspeech-0.9.3-models.pbmm",
            "deepspeech-0.9.3-models.scorer": "https://github.com/mozilla/DeepSpeech/releases/download/v0.9.3/deepspeech-0.9.3-models.scorer"
        }
        
        for filename, url in model_urls.items():
            file_path = model_dir / filename
            if not file_path.exists():
                logger.info(f"Downloading {filename}")
                # Use wget or curl to download
                process = await asyncio.create_subprocess_exec(
                    "wget", "-O", str(file_path), url,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE
                )
                await process.communicate()
    
    async def transcribe_audio(self, audio_file_path: str) -> TranscriptionResult:
        """Transcribe audio file using DeepSpeech"""
        
        if not self.initialized:
            await self.initialize()
        
        try:
            logger.info("Starting audio transcription", file=audio_file_path)
            
            # Convert audio to required format (16kHz, mono, WAV)
            processed_audio_path = await self._preprocess_audio(audio_file_path)
            
            # Read audio data
            with wave.open(processed_audio_path, 'rb') as audio_file:
                frames = audio_file.getnframes()
                buffer = audio_file.readframes(frames)
                data16 = np.frombuffer(buffer, dtype=np.int16)
            
            # Run inference
            text = self.model.stt(data16)
            
            # Get detailed metadata
            metadata = self.model.sttWithMetadata(data16, num_results=1)
            
            # Extract timestamps and confidence
            timestamps = []
            confidence_scores = []
            
            if metadata.transcripts:
                transcript = metadata.transcripts[0]
                for token in transcript.tokens:
                    timestamps.append({
                        "text": token.text,
                        "start_time": token.start_time,
                        "duration": token.duration
                    })
                confidence_scores.append(transcript.confidence)
            
            # Clean up temporary file
            if processed_audio_path != audio_file_path:
                os.unlink(processed_audio_path)
            
            result = TranscriptionResult(
                text=text,
                confidence=metadata.confidence if metadata.transcripts else 0.0,
                timestamps=timestamps,
                language="en-US",  # DeepSpeech default
                processing_time=0,  # Could be measured
                metadata={
                    "model": "mozilla-deepspeech-0.9.3",
                    "privacy_mode": "local",
                    "frames_processed": frames
                }
            )
            
            logger.info(
                "Audio transcription completed",
                text_length=len(text),
                confidence=result.confidence
            )
            
            return result
            
        except Exception as e:
            logger.error("Audio transcription failed", error=str(e), exc_info=True)
            raise
    
    async def _preprocess_audio(self, audio_file_path: str) -> str:
        """Convert audio to format required by DeepSpeech"""
        
        try:
            # Load audio with librosa
            audio_data, sample_rate = librosa.load(audio_file_path, sr=16000, mono=True)
            
            # Convert to int16
            audio_int16 = (audio_data * 32767).astype(np.int16)
            
            # Create temporary WAV file
            with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as temp_file:
                temp_path = temp_file.name
            
            # Write WAV file
            with wave.open(temp_path, 'wb') as wav_file:
                wav_file.setnchannels(1)  # Mono
                wav_file.setsampwidth(2)  # 16-bit
                wav_file.setframerate(16000)  # 16kHz
                wav_file.writeframes(audio_int16.tobytes())
            
            return temp_path
            
        except Exception as e:
            logger.error("Audio preprocessing failed", error=str(e))
            raise

class MozillaTTSEngine:
    """Mozilla TTS integration for high-quality speech synthesis"""
    
    def __init__(self):
        self.model_path = settings.MOZILLA_TTS_MODEL_PATH
        self.initialized = False
        self.synthesizer = None
        self.voice_bank = CommonVoiceBank()
    
    async def initialize(self):
        """Initialize Mozilla TTS"""
        try:
            logger.info("Initializing Mozilla TTS", model_path=self.model_path)
            
            # Check if TTS is available
            try:
                from TTS.api import TTS
                
                # Initialize TTS with Tacotron2 + WaveGlow
                self.tts = TTS(
                    model_name="tts_models/en/ljspeech/tacotron2-DDC",
                    vocoder_name="vocoder_models/en/ljspeech/hifigan_v2"
                )
                
                self.initialized = True
                logger.info("Mozilla TTS initialized successfully")
                
            except ImportError:
                logger.error("Mozilla TTS not available, falling back to espeak")
                self.initialized = False
                
        except Exception as e:
            logger.error("Failed to initialize Mozilla TTS", error=str(e))
            raise
    
    async def synthesize_speech(
        self, 
        text: str, 
        voice_profile: VoiceProfile,
        output_path: Optional[str] = None
    ) -> GeneratedAudio:
        """Generate speech from text using Mozilla TTS"""
        
        if not self.initialized:
            await self.initialize()
        
        try:
            logger.info(
                "Starting speech synthesis",
                text_length=len(text),
                voice=voice_profile.name if voice_profile else "default"
            )
            
            if not output_path:
                # Create temporary output file
                temp_file = tempfile.NamedTemporaryFile(suffix=".wav", delete=False)
                output_path = temp_file.name
                temp_file.close()
            
            if self.initialized and hasattr(self, 'tts'):
                # Use Mozilla TTS
                self.tts.tts_to_file(
                    text=text,
                    file_path=output_path
                )
            else:
                # Fallback to espeak
                await self._synthesize_with_espeak(text, output_path, voice_profile)
            
            # Get audio metadata
            audio_segment = AudioSegment.from_wav(output_path)
            duration = len(audio_segment) / 1000.0  # Convert to seconds
            
            result = GeneratedAudio(
                audio_path=output_path,
                duration=duration,
                sample_rate=audio_segment.frame_rate,
                channels=audio_segment.channels,
                voice_profile=voice_profile,
                metadata={
                    "engine": "mozilla-tts" if self.initialized else "espeak",
                    "model": "tacotron2-ddc" if self.initialized else "espeak",
                    "privacy_mode": "local",
                    "text_length": len(text)
                }
            )
            
            logger.info(
                "Speech synthesis completed",
                duration=duration,
                output_path=output_path
            )
            
            return result
            
        except Exception as e:
            logger.error("Speech synthesis failed", error=str(e), exc_info=True)
            raise
    
    async def _synthesize_with_espeak(
        self, 
        text: str, 
        output_path: str, 
        voice_profile: Optional[VoiceProfile]
    ):
        """Fallback synthesis using espeak"""
        
        # Build espeak command
        cmd = ["espeak", "-w", output_path]
        
        if voice_profile:
            # Map voice profile to espeak voice
            if voice_profile.gender == "female":
                cmd.extend(["-v", "en+f3"])
            else:
                cmd.extend(["-v", "en+m3"])
            
            # Adjust speed and pitch
            cmd.extend(["-s", "150"])  # Speed
            cmd.extend(["-p", "50"])   # Pitch
        
        cmd.append(text)
        
        # Run espeak
        process = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )
        
        stdout, stderr = await process.communicate()
        
        if process.returncode != 0:
            raise RuntimeError(f"espeak failed: {stderr.decode()}")

class CommonVoiceBank:
    """Mozilla Common Voice dataset integration"""
    
    def __init__(self):
        self.dataset_path = Path(settings.COMMON_VOICE_PATH)
        self.voice_profiles = {}
        self.languages = []
    
    async def initialize(self):
        """Initialize Common Voice dataset"""
        try:
            logger.info("Initializing Common Voice dataset", path=self.dataset_path)
            
            if not self.dataset_path.exists():
                logger.warning("Common Voice dataset not found")
                return
            
            # Load voice profiles from dataset
            await self._load_voice_profiles()
            
            logger.info(
                "Common Voice initialized",
                profiles_loaded=len(self.voice_profiles),
                languages=len(self.languages)
            )
            
        except Exception as e:
            logger.error("Failed to initialize Common Voice", error=str(e))
    
    async def _load_voice_profiles(self):
        """Load voice profiles from Common Voice dataset"""
        
        # This would load actual Common Voice data
        # For now, create sample profiles
        sample_profiles = [
            VoiceProfile(
                id="cv-en-us-female-1",
                name="Sarah",
                language="en-US",
                gender="female",
                accent="General American",
                description="Clear, professional voice from Common Voice",
                sample_url=None
            ),
            VoiceProfile(
                id="cv-en-us-male-1",
                name="Marcus",
                language="en-US", 
                gender="male",
                accent="General American",
                description="Warm, engaging voice from Common Voice",
                sample_url=None
            ),
            VoiceProfile(
                id="cv-en-us-female-2",
                name="Alex",
                language="en-US",
                gender="female",
                accent="California",
                description="Youthful, energetic voice from Common Voice",
                sample_url=None
            )
        ]
        
        for profile in sample_profiles:
            self.voice_profiles[profile.id] = profile
        
        self.languages = ["en-US", "es-ES", "fr-FR", "de-DE"]
    
    def get_voice_profile(self, profile_id: str) -> Optional[VoiceProfile]:
        """Get voice profile by ID"""
        return self.voice_profiles.get(profile_id)
    
    def get_diverse_voices(self, criteria: Dict[str, Any]) -> List[VoiceProfile]:
        """Get diverse voice selection based on criteria"""
        
        # Filter profiles based on criteria
        filtered_profiles = []
        
        for profile in self.voice_profiles.values():
            if criteria.get("language") and profile.language != criteria["language"]:
                continue
            if criteria.get("gender") and profile.gender != criteria["gender"]:
                continue
            
            filtered_profiles.append(profile)
        
        # Return diverse selection
        return filtered_profiles[:5]  # Limit to 5 voices
    
    async def contribute_voice_sample(
        self, 
        user_id: str, 
        audio_data: bytes, 
        transcript: str,
        language: str
    ) -> Dict[str, Any]:
        """Accept voice contribution to Common Voice dataset"""
        
        # Privacy-preserving voice contribution
        # This would integrate with actual Common Voice contribution system
        
        logger.info(
            "Voice contribution received",
            user_id=user_id,
            language=language,
            transcript_length=len(transcript)
        )
        
        return {
            "contribution_id": f"contrib_{user_id}_{int(asyncio.get_event_loop().time())}",
            "status": "accepted",
            "privacy_preserved": True,
            "anonymized": True
        }

class MozillaServiceOrchestrator:
    """Orchestrates all Mozilla services"""
    
    def __init__(self):
        self.deepspeech = MozillaDeepSpeechProcessor()
        self.tts = MozillaTTSEngine()
        self.common_voice = CommonVoiceBank()
        self.initialized = False
    
    async def initialize(self):
        """Initialize all Mozilla services"""
        try:
            logger.info("Initializing Mozilla service orchestrator")
            
            # Initialize services in parallel
            await asyncio.gather(
                self.deepspeech.initialize(),
                self.tts.initialize(),
                self.common_voice.initialize()
            )
            
            self.initialized = True
            logger.info("Mozilla services initialized successfully")
            
        except Exception as e:
            logger.error("Failed to initialize Mozilla services", error=str(e))
            # Don't raise - allow partial initialization
    
    async def process_audio_input(self, audio_file_path: str) -> TranscriptionResult:
        """Process audio input with DeepSpeech"""
        return await self.deepspeech.transcribe_audio(audio_file_path)
    
    async def generate_voices(
        self,
        dialogue_segments: List[Dict[str, Any]],
        voice_assignments: Dict[str, VoiceProfile]
    ) -> List[GeneratedAudio]:
        """Generate voices for dialogue segments"""
        
        audio_segments = []
        
        for segment in dialogue_segments:
            speaker = segment.get("speaker")
            text = segment.get("text", "")
            
            if not text or not speaker:
                continue
            
            voice_profile = voice_assignments.get(speaker)
            if not voice_profile:
                # Use default voice
                voice_profile = list(self.common_voice.voice_profiles.values())[0]
            
            # Generate audio
            audio = await self.tts.synthesize_speech(text, voice_profile)
            audio_segments.append(audio)
        
        return audio_segments
    
    def get_health_status(self) -> Dict[str, Any]:
        """Get health status of all Mozilla services"""
        return {
            "deepspeech": {
                "initialized": self.deepspeech.initialized,
                "model_loaded": self.deepspeech.model is not None
            },
            "tts": {
                "initialized": self.tts.initialized,
                "engine": "mozilla-tts" if self.tts.initialized else "espeak"
            },
            "common_voice": {
                "profiles_available": len(self.common_voice.voice_profiles),
                "languages_supported": len(self.common_voice.languages)
            }
        }