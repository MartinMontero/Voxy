"""
OpenAI blocking service for Voxy
Critical security component - ensures no OpenAI services are used
"""

import re
import ast
import inspect
import sys
import importlib
from typing import List, Dict, Any, Optional
import structlog
from pathlib import Path

from app.core.config import settings

logger = structlog.get_logger()

class OpenAIBlocker:
    """Comprehensive OpenAI blocking and detection service"""
    
    def __init__(self):
        self.blocked_packages = [
            "openai",
            "openai-python", 
            "openai-api",
            "azure-openai",
            "langchain-openai"
        ]
        
        self.blocked_domains = settings.BLOCKED_DOMAINS
        
        self.blocked_terms = [
            "openai",
            "gpt-3",
            "gpt-4", 
            "gpt-3.5",
            "chatgpt",
            "dall-e",
            "whisper",
            "codex",
            "davinci",
            "curie",
            "babbage",
            "ada"
        ]
        
        self.blocked_api_patterns = [
            r"sk-[a-zA-Z0-9]{48}",  # OpenAI API key pattern
            r"org-[a-zA-Z0-9]{24}", # OpenAI org ID pattern
        ]
        
        # Perform initial validation
        self._validate_environment()
    
    def _validate_environment(self):
        """Validate that OpenAI packages are not installed"""
        
        logger.info("Validating OpenAI-free environment")
        
        violations = []
        
        # Check installed packages
        for package in self.blocked_packages:
            try:
                importlib.import_module(package)
                violations.append(f"CRITICAL: {package} package is installed")
            except ImportError:
                pass  # Good - package not found
        
        # Check sys.modules for loaded OpenAI modules
        for module_name in sys.modules.keys():
            if any(blocked in module_name.lower() for blocked in ["openai"]):
                violations.append(f"CRITICAL: {module_name} module is loaded")
        
        if violations:
            logger.critical("OpenAI SECURITY VIOLATIONS DETECTED", violations=violations)
            raise RuntimeError(f"OpenAI blocking failed: {violations}")
        
        logger.info("Environment validation passed - no OpenAI packages detected")
    
    async def scan_code_for_openai(self, code_content: str) -> Dict[str, Any]:
        """Scan code content for OpenAI usage"""
        
        violations = []
        
        try:
            # Parse code into AST
            tree = ast.parse(code_content)
            
            # Walk through AST nodes
            for node in ast.walk(tree):
                # Check imports
                if isinstance(node, ast.Import):
                    for alias in node.names:
                        if any(blocked in alias.name.lower() for blocked in self.blocked_terms):
                            violations.append(f"Blocked import: {alias.name}")
                
                elif isinstance(node, ast.ImportFrom):
                    if node.module and any(blocked in node.module.lower() for blocked in self.blocked_terms):
                        violations.append(f"Blocked import from: {node.module}")
                
                # Check string literals for API keys or endpoints
                elif isinstance(node, ast.Str):
                    for pattern in self.blocked_api_patterns:
                        if re.search(pattern, node.s):
                            violations.append(f"Potential OpenAI API key detected")
                    
                    if any(domain in node.s.lower() for domain in self.blocked_domains):
                        violations.append(f"OpenAI domain reference: {node.s}")
        
        except SyntaxError:
            # If code can't be parsed, do text-based scan
            violations.extend(self._scan_text_for_openai(code_content))
        
        return {
            "violations_found": len(violations) > 0,
            "violations": violations,
            "scan_type": "code_ast"
        }
    
    def _scan_text_for_openai(self, text: str) -> List[str]:
        """Text-based scan for OpenAI references"""
        
        violations = []
        text_lower = text.lower()
        
        # Check for blocked terms
        for term in self.blocked_terms:
            if term in text_lower:
                violations.append(f"Blocked term found: {term}")
        
        # Check for API key patterns
        for pattern in self.blocked_api_patterns:
            matches = re.findall(pattern, text)
            for match in matches:
                violations.append(f"Potential API key pattern: {match[:10]}...")
        
        # Check for domain references
        for domain in self.blocked_domains:
            if domain in text_lower:
                violations.append(f"Blocked domain reference: {domain}")
        
        return violations
    
    async def scan_request_headers(self, headers: Dict[str, str]) -> Dict[str, Any]:
        """Scan HTTP request headers for OpenAI usage"""
        
        violations = []
        
        for header_name, header_value in headers.items():
            header_lower = header_value.lower()
            
            # Check authorization headers for OpenAI API keys
            if header_name.lower() == "authorization":
                for pattern in self.blocked_api_patterns:
                    if re.search(pattern, header_value):
                        violations.append("OpenAI API key detected in Authorization header")
                
                if "openai" in header_lower:
                    violations.append("OpenAI reference in Authorization header")
            
            # Check other headers
            if any(term in header_lower for term in self.blocked_terms):
                violations.append(f"Blocked term in header {header_name}: {header_value}")
        
        return {
            "violations_found": len(violations) > 0,
            "violations": violations,
            "scan_type": "request_headers"
        }
    
    async def scan_request_body(self, body: str) -> Dict[str, Any]:
        """Scan request body for OpenAI usage"""
        
        if not body:
            return {"violations_found": False, "violations": [], "scan_type": "request_body"}
        
        violations = self._scan_text_for_openai(body)
        
        # Additional JSON-specific checks
        try:
            import json
            data = json.loads(body)
            
            # Recursively check JSON values
            violations.extend(self._scan_json_for_openai(data))
            
        except json.JSONDecodeError:
            pass  # Not JSON, text scan is sufficient
        
        return {
            "violations_found": len(violations) > 0,
            "violations": violations,
            "scan_type": "request_body"
        }
    
    def _scan_json_for_openai(self, data: Any, path: str = "") -> List[str]:
        """Recursively scan JSON data for OpenAI references"""
        
        violations = []
        
        if isinstance(data, dict):
            for key, value in data.items():
                current_path = f"{path}.{key}" if path else key
                
                # Check key names
                if any(term in key.lower() for term in self.blocked_terms):
                    violations.append(f"Blocked term in JSON key: {current_path}")
                
                # Recursively check values
                violations.extend(self._scan_json_for_openai(value, current_path))
        
        elif isinstance(data, list):
            for i, item in enumerate(data):
                current_path = f"{path}[{i}]" if path else f"[{i}]"
                violations.extend(self._scan_json_for_openai(item, current_path))
        
        elif isinstance(data, str):
            # Check string values
            violations.extend(self._scan_text_for_openai(data))
        
        return violations
    
    async def scan_file_system(self, directory: Path) -> Dict[str, Any]:
        """Scan file system for OpenAI-related files"""
        
        violations = []
        
        # File patterns to check
        suspicious_patterns = [
            "*.openai.*",
            "*gpt*",
            "*chatgpt*",
            "*.env*"  # Check env files for API keys
        ]
        
        for pattern in suspicious_patterns:
            for file_path in directory.rglob(pattern):
                if file_path.is_file():
                    # Check filename
                    if any(term in file_path.name.lower() for term in self.blocked_terms):
                        violations.append(f"Suspicious filename: {file_path}")
                    
                    # Check file content if it's a text file
                    if file_path.suffix in ['.py', '.js', '.ts', '.json', '.env', '.txt']:
                        try:
                            content = file_path.read_text()
                            file_violations = self._scan_text_for_openai(content)
                            for violation in file_violations:
                                violations.append(f"{file_path}: {violation}")
                        except Exception:
                            pass  # Skip files that can't be read
        
        return {
            "violations_found": len(violations) > 0,
            "violations": violations,
            "scan_type": "file_system",
            "directory_scanned": str(directory)
        }
    
    def generate_compliance_report(self) -> Dict[str, Any]:
        """Generate comprehensive compliance report"""
        
        report = {
            "timestamp": logger.info("Generating OpenAI compliance report"),
            "environment_status": "compliant",
            "blocked_packages": self.blocked_packages,
            "blocked_domains": self.blocked_domains,
            "blocked_terms": self.blocked_terms,
            "security_level": "maximum",
            "violations_detected": [],
            "recommendations": [
                "Continue monitoring for OpenAI package installations",
                "Regularly scan code repositories for OpenAI references", 
                "Maintain strict API key policies",
                "Use only approved AI services (Anthropic Claude, Mozilla)"
            ]
        }
        
        # Re-validate environment
        try:
            self._validate_environment()
        except RuntimeError as e:
            report["environment_status"] = "non_compliant"
            report["violations_detected"].append(str(e))
        
        logger.info("OpenAI compliance report generated", status=report["environment_status"])
        
        return report
    
    def get_approved_alternatives(self) -> Dict[str, Any]:
        """Get list of approved AI service alternatives"""
        
        return {
            "language_models": {
                "primary": "Anthropic Claude",
                "alternatives": ["LLaMA 2", "Mistral", "Falcon", "BLOOM"],
                "blocked": ["OpenAI GPT", "ChatGPT"]
            },
            "speech_recognition": {
                "primary": "Mozilla DeepSpeech",
                "alternatives": ["Wav2Vec2", "Whisper.cpp (local)"],
                "blocked": ["OpenAI Whisper API"]
            },
            "speech_synthesis": {
                "primary": "Mozilla TTS",
                "alternatives": ["Coqui TTS", "Festival", "eSpeak"],
                "blocked": ["OpenAI TTS"]
            },
            "image_generation": {
                "primary": "Stable Diffusion",
                "alternatives": ["DALL-E Mini", "Midjourney"],
                "blocked": ["OpenAI DALL-E"]
            }
        }

# Global instance
openai_blocker = OpenAIBlocker()