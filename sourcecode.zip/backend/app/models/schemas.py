"""
Pydantic schemas for Voxy API
"""

from pydantic import BaseModel, Field, validator
from typing import List, Optional, Dict, Any, Union
from datetime import datetime
from uuid import UUID
from enum import Enum

# Enums
class ProcessingMode(str, Enum):
    CLOUD = "cloud"
    LOCAL = "local"
    HYBRID = "hybrid"

class PrivacyLevel(str, Enum):
    MAXIMUM = "maximum"
    BALANCED = "balanced"
    PERFORMANCE = "performance"

class DocumentStatus(str, Enum):
    UPLOADING = "uploading"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"

class GenerationStatus(str, Enum):
    PENDING = "pending"
    ANALYZING = "analyzing"
    GENERATING = "generating"
    SYNTHESIZING = "synthesizing"
    COMPLETED = "completed"
    FAILED = "failed"

# Base schemas
class VoiceProfile(BaseModel):
    id: str
    name: str
    language: str
    gender: str
    accent: Optional[str] = None
    description: Optional[str] = None
    sample_url: Optional[str] = None

class Persona(BaseModel):
    id: str
    name: str
    role: str
    personality: str
    description: str
    voice_profile: Optional[VoiceProfile] = None

class Citation(BaseModel):
    id: str
    text: str
    source: str
    page: Optional[int] = None
    timestamp: Optional[float] = None
    confidence: Optional[float] = None

class DialogueSegment(BaseModel):
    id: str
    speaker: str
    text: str
    timestamp: float
    citations: List[str] = []

class TranscriptionResult(BaseModel):
    text: str
    confidence: float
    timestamps: List[Dict[str, Any]] = []
    language: str
    processing_time: Optional[float] = None
    metadata: Dict[str, Any] = {}

class GeneratedAudio(BaseModel):
    audio_path: str
    duration: float
    sample_rate: int
    channels: int
    voice_profile: Optional[VoiceProfile] = None
    metadata: Dict[str, Any] = {}

# User schemas
class UserBase(BaseModel):
    email: str
    full_name: Optional[str] = None

class UserCreate(UserBase):
    password: str = Field(..., min_length=8)

class UserUpdate(BaseModel):
    full_name: Optional[str] = None
    privacy_preferences: Optional[Dict[str, Any]] = None
    default_processing_mode: Optional[ProcessingMode] = None
    default_privacy_level: Optional[PrivacyLevel] = None

class UserResponse(UserBase):
    id: UUID
    is_active: bool
    is_verified: bool
    privacy_preferences: Dict[str, Any] = {}
    default_processing_mode: ProcessingMode
    default_privacy_level: PrivacyLevel
    mozilla_contributor: bool = False
    created_at: datetime
    
    class Config:
        from_attributes = True

# Document schemas
class DocumentBase(BaseModel):
    filename: str
    file_type: str
    file_size: int

class DocumentCreate(DocumentBase):
    pass

class DocumentResponse(DocumentBase):
    id: UUID
    project_id: UUID
    original_filename: str
    status: DocumentStatus
    extracted_text: Optional[str] = None
    is_audio: bool = False
    audio_duration: Optional[int] = None
    transcription_confidence: Optional[int] = None
    language_detected: Optional[str] = None
    uploaded_at: datetime
    processed_at: Optional[datetime] = None
    
    class Config:
        from_attributes = True

# Generation settings
class GenerationSettings(BaseModel):
    duration: int = Field(default=10, ge=5, le=20, description="Duration in minutes")
    tone: str = Field(default="balanced", regex="^(educational|entertaining|balanced|debate)$")
    personas: List[Persona] = Field(default=[], max_items=5)
    focus_areas: Optional[List[str]] = None
    include_intro: bool = True
    include_conclusion: bool = True
    language: str = Field(default="en-US")
    
    @validator('personas')
    def validate_personas(cls, v):
        if len(v) < 1:
            raise ValueError('At least one persona is required')
        if len(v) > 5:
            raise ValueError('Maximum 5 personas allowed')
        return v

# Project schemas
class ProjectBase(BaseModel):
    name: str = Field(..., min_length=1, max_length=200)
    description: Optional[str] = Field(None, max_length=1000)

class ProjectCreate(ProjectBase):
    processing_mode: ProcessingMode = ProcessingMode.BALANCED
    privacy_level: PrivacyLevel = PrivacyLevel.BALANCED
    generation_settings: Optional[GenerationSettings] = None

class ProjectUpdate(BaseModel):
    name: Optional[str] = Field(None, min_length=1, max_length=200)
    description: Optional[str] = Field(None, max_length=1000)
    processing_mode: Optional[ProcessingMode] = None
    privacy_level: Optional[PrivacyLevel] = None
    generation_settings: Optional[GenerationSettings] = None

class ProjectResponse(ProjectBase):
    id: UUID
    user_id: UUID
    processing_mode: ProcessingMode
    privacy_level: PrivacyLevel
    generation_settings: Dict[str, Any] = {}
    selected_personas: List[Dict[str, Any]] = []
    generated_audio_url: Optional[str] = None
    transcript: Optional[str] = None
    citations: List[Dict[str, Any]] = []
    status: GenerationStatus
    generation_progress: int = 0
    error_message: Optional[str] = None
    created_at: datetime
    updated_at: datetime
    generated_at: Optional[datetime] = None
    documents: List[DocumentResponse] = []
    
    class Config:
        from_attributes = True

class ProjectListResponse(BaseModel):
    projects: List[ProjectResponse]
    total: int
    skip: int
    limit: int

# Authentication schemas
class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"
    expires_in: int

class TokenData(BaseModel):
    user_id: Optional[str] = None

class LoginRequest(BaseModel):
    email: str
    password: str

# Mozilla service schemas
class TranscribeRequest(BaseModel):
    language: str = "en-US"
    privacy_mode: str = "local"

class SynthesizeRequest(BaseModel):
    text: str = Field(..., min_length=1, max_length=5000)
    voice: str = "default"
    language: str = "en-US"
    speed: float = Field(default=1.0, ge=0.5, le=2.0)
    pitch: float = Field(default=1.0, ge=0.5, le=2.0)

class VoiceContributionRequest(BaseModel):
    transcript: str = Field(..., min_length=1, max_length=500)
    language: str = "en-US"
    consent_version: str = "1.0"

# Privacy and security schemas
class PrivacySettings(BaseModel):
    processing_mode: ProcessingMode
    privacy_level: PrivacyLevel
    enable_local_processing: bool = True
    enable_anonymous_mode: bool = True
    data_retention_days: int = Field(default=30, ge=1, le=365)

class SecurityReport(BaseModel):
    timestamp: datetime
    environment_status: str
    blocked_packages: List[str]
    blocked_domains: List[str]
    violations_detected: List[str]
    recommendations: List[str]

# Health check schemas
class HealthCheck(BaseModel):
    status: str
    service: str
    version: str
    ai_services: Dict[str, Any]
    timestamp: datetime = Field(default_factory=datetime.utcnow)

class ServiceHealth(BaseModel):
    service_name: str
    status: str
    last_check: datetime
    details: Dict[str, Any] = {}

# Error schemas
class ErrorResponse(BaseModel):
    detail: str
    type: str
    timestamp: datetime = Field(default_factory=datetime.utcnow)

# File upload schemas
class FileUploadResponse(BaseModel):
    document_id: UUID
    filename: str
    file_size: int
    status: DocumentStatus
    message: str

# Generation job schemas
class GenerationJobResponse(BaseModel):
    job_id: UUID
    project_id: UUID
    status: GenerationStatus
    progress: int
    estimated_completion: Optional[datetime] = None
    result_url: Optional[str] = None
    error_message: Optional[str] = None

# Persona management schemas
class PersonaCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=100)
    role: str = Field(..., min_length=1, max_length=100)
    personality: str = Field(..., min_length=10, max_length=1000)
    description: str = Field(..., min_length=10, max_length=500)
    voice_profile_id: Optional[str] = None

class PersonaResponse(BaseModel):
    id: UUID
    user_id: Optional[UUID] = None
    name: str
    role: str
    personality: str
    description: str
    voice_profile_id: Optional[str] = None
    is_default: bool = False
    usage_count: int = 0
    average_rating: float = 0.0
    created_at: datetime
    
    class Config:
        from_attributes = True

# Analytics schemas (privacy-preserving)
class UsageStats(BaseModel):
    total_projects: int
    total_generations: int
    total_documents_processed: int
    average_generation_time: float
    privacy_mode_distribution: Dict[str, int]
    language_distribution: Dict[str, int]
    # No personal data included

class PlatformMetrics(BaseModel):
    active_users_24h: int
    total_podcasts_generated: int
    total_audio_minutes: float
    mozilla_transcriptions: int
    anthropic_generations: int
    privacy_stats: Dict[str, Any]
    # Aggregated, anonymized data only