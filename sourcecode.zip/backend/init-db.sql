-- Voxy Database Initialization Script
-- AI-Powered Podcast Generation Platform

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Enable pgvector extension for embeddings (if available)
CREATE EXTENSION IF NOT EXISTS vector;

-- Create custom types
CREATE TYPE processing_mode AS ENUM ('cloud', 'local', 'hybrid');
CREATE TYPE privacy_level AS ENUM ('maximum', 'balanced', 'performance');
CREATE TYPE document_status AS ENUM ('uploading', 'processing', 'completed', 'failed');
CREATE TYPE generation_status AS ENUM ('pending', 'analyzing', 'generating', 'synthesizing', 'completed', 'failed');

-- Insert default personas
INSERT INTO personas (id, name, role, personality, description, voice_gender, voice_language, is_default, created_at, updated_at) VALUES
(
    uuid_generate_v4(),
    'Dr. Sarah Chen',
    'Subject Matter Expert',
    'Analytical, thorough, and precise. Focuses on accuracy and evidence-based insights.',
    'A research scientist who breaks down complex topics with clarity and depth.',
    'female',
    'en-US',
    true,
    NOW(),
    NOW()
),
(
    uuid_generate_v4(),
    'Marcus Rivera',
    'Investigative Journalist',
    'Curious, probing, and skeptical. Asks tough questions and seeks the truth.',
    'An experienced journalist who challenges assumptions and digs deeper.',
    'male',
    'en-US',
    true,
    NOW(),
    NOW()
),
(
    uuid_generate_v4(),
    'Alex Kim',
    'Curious Student',
    'Enthusiastic, inquisitive, and relatable. Asks questions the audience might have.',
    'A bright student who represents the audience''s perspective and learning journey.',
    'female',
    'en-US',
    true,
    NOW(),
    NOW()
),
(
    uuid_generate_v4(),
    'Dr. James Wright',
    'Critical Analyst',
    'Methodical, logical, and balanced. Evaluates arguments from multiple angles.',
    'A philosopher who examines ideas critically and presents balanced viewpoints.',
    'male',
    'en-US',
    true,
    NOW(),
    NOW()
),
(
    uuid_generate_v4(),
    'Maya Patel',
    'Creative Storyteller',
    'Imaginative, engaging, and empathetic. Makes content accessible and memorable.',
    'A creative writer who transforms complex ideas into compelling narratives.',
    'female',
    'en-US',
    true,
    NOW(),
    NOW()
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_projects_user_id ON projects(user_id);
CREATE INDEX IF NOT EXISTS idx_projects_status ON projects(status);
CREATE INDEX IF NOT EXISTS idx_projects_updated_at ON projects(updated_at DESC);

CREATE INDEX IF NOT EXISTS idx_documents_project_id ON documents(project_id);
CREATE INDEX IF NOT EXISTS idx_documents_status ON documents(status);
CREATE INDEX IF NOT EXISTS idx_documents_content_hash ON documents(content_hash);

CREATE INDEX IF NOT EXISTS idx_personas_is_default ON personas(is_default);
CREATE INDEX IF NOT EXISTS idx_personas_user_id ON personas(user_id);

CREATE INDEX IF NOT EXISTS idx_audit_logs_user_id ON audit_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_timestamp ON audit_logs(timestamp DESC);

-- Create full-text search indexes
CREATE INDEX IF NOT EXISTS idx_documents_text_search ON documents USING gin(to_tsvector('english', extracted_text));

-- Grant permissions
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO voxy;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO voxy;