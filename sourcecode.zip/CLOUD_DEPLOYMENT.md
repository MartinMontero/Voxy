# Voxy Cloud Deployment Guide

## 🌐 **SCALABLE CLOUD DEPLOYMENT OPTIONS**

This guide provides step-by-step instructions for deploying Voxy to various cloud platforms, from simple static hosting to full production infrastructure.

---

## 📋 **DEPLOYMENT ARCHITECTURE OVERVIEW**

### **Frontend-Only Deployments**
For demo/MVP purposes - static hosting with API mocking:
- ✅ **Netlify** - Best for quick demos
- ✅ **Vercel** - Excellent performance and DX
- ✅ **GitHub Pages** - Free and simple
- ✅ **Cloudflare Pages** - Global CDN

### **Full-Stack Deployments**
Complete application with backend and database:
- 🚀 **Railway** - Easiest full-stack deployment
- 🚀 **Render** - Great for production apps
- 🚀 **DigitalOcean App Platform** - Managed containers
- 🚀 **AWS/GCP/Azure** - Enterprise-grade infrastructure

---

## 🎯 **OPTION 1: NETLIFY (Frontend + Mock Backend)**

### Quick Demo Deployment

```bash
# 1. Build for production
npm run build

# 2. Install Netlify CLI
npm install -g netlify-cli

# 3. Deploy
netlify deploy --prod --dir=dist
```

### Automated Deployment

Create `netlify.toml`:

```toml
[build]
  publish = "dist"
  command = "npm run build"

[build.environment]
  NODE_VERSION = "18"
  VITE_API_URL = "https://your-backend.railway.app"
  VITE_PRIVACY_MODE = "enabled"
  VITE_MOZILLA_SERVICES = "true"
  VITE_OPENAI_BLOCKED = "true"

[[redirects]]
  from = "/*"
  to = "/index.html"
  status = 200

[[headers]]
  for = "/*"
  [headers.values]
    X-Frame-Options = "DENY"
    X-Content-Type-Options = "nosniff"
    X-XSS-Protection = "1; mode=block"
    X-Voxy-Privacy = "enabled"
    X-OpenAI-Blocked = "true"
    X-Mozilla-Powered = "true"

[[headers]]
  for = "/assets/*"
  [headers.values]
    Cache-Control = "public, max-age=31536000, immutable"
```

**Steps:**
1. Push code to GitHub
2. Connect repository to Netlify
3. Configure environment variables
4. Deploy automatically on push

**Result:** `https://your-app.netlify.app`

---

## 🚀 **OPTION 2: VERCEL (Frontend + Serverless Functions)**

### Quick Deployment

```bash
# 1. Install Vercel CLI
npm install -g vercel

# 2. Deploy
vercel --prod
```

### Configuration

Create `vercel.json`:

```json
{
  "buildCommand": "npm run build",
  "outputDirectory": "dist",
  "framework": "vite",
  "rewrites": [
    { "source": "/(.*)", "destination": "/index.html" }
  ],
  "headers": [
    {
      "source": "/(.*)",
      "headers": [
        { "key": "X-Frame-Options", "value": "DENY" },
        { "key": "X-Content-Type-Options", "value": "nosniff" },
        { "key": "X-Voxy-Privacy", "value": "enabled" },
        { "key": "X-OpenAI-Blocked", "value": "true" }
      ]
    }
  ],
  "env": {
    "VITE_API_URL": "https://your-backend.railway.app",
    "VITE_PRIVACY_MODE": "enabled",
    "VITE_OPENAI_BLOCKED": "true"
  }
}
```

**Result:** `https://your-app.vercel.app`

---

## 📄 **OPTION 3: GITHUB PAGES (Free Static Hosting)**

### GitHub Actions Deployment

Create `.github/workflows/deploy.yml`:

```yaml
name: Deploy to GitHub Pages

on:
  push:
    branches: [ main ]

jobs:
  deploy:
    runs-on: ubuntu-latest
    
    steps:
    - uses: actions/checkout@v3
    
    - name: Setup Node.js
      uses: actions/setup-node@v3
      with:
        node-version: '18'
        cache: 'npm'
    
    - name: Install dependencies
      run: npm ci
    
    - name: Build
      run: npm run build
      env:
        VITE_API_URL: ${{ secrets.VITE_API_URL }}
        VITE_PRIVACY_MODE: enabled
        VITE_OPENAI_BLOCKED: true
    
    - name: Deploy to GitHub Pages
      uses: peaceiris/actions-gh-pages@v3
      with:
        github_token: ${{ secrets.GITHUB_TOKEN }}
        publish_dir: ./dist
```

**Steps:**
1. Enable GitHub Pages in repository settings
2. Add secrets for environment variables
3. Push to main branch
4. Automatic deployment

**Result:** `https://username.github.io/voxy`

---

## ⚡ **OPTION 4: CLOUDFLARE PAGES**

### Deployment

```bash
# 1. Install Wrangler CLI
npm install -g wrangler

# 2. Login to Cloudflare
wrangler login

# 3. Create and deploy
wrangler pages project create voxy
wrangler pages publish dist --project-name=voxy
```

### Configuration

Create `_headers` file in `public/`:

```
/*
  X-Frame-Options: DENY
  X-Content-Type-Options: nosniff
  X-XSS-Protection: 1; mode=block
  X-Voxy-Privacy: enabled
  X-OpenAI-Blocked: true
  X-Mozilla-Powered: true

/assets/*
  Cache-Control: public, max-age=31536000, immutable
```

**Result:** `https://voxy.pages.dev`

---

## 🚂 **OPTION 5: RAILWAY (Full-Stack with Database)**

### Complete Application Deployment

**1. Backend Deployment**

Create `railway.json`:

```json
{
  "build": {
    "builder": "DOCKERFILE",
    "dockerfilePath": "backend/Dockerfile"
  },
  "deploy": {
    "startCommand": "uvicorn app.main:app --host 0.0.0.0 --port $PORT",
    "healthcheckPath": "/health",
    "healthcheckTimeout": 100
  }
}
```

**2. Database Setup**

```bash
# Add PostgreSQL service
railway add postgresql

# Add Redis service  
railway add redis

# Set environment variables
railway variables set ANTHROPIC_API_KEY=your_key_here
railway variables set DATABASE_URL=$DATABASE_URL
railway variables set REDIS_URL=$REDIS_URL
```

**3. Frontend Deployment**

```bash
# Deploy frontend separately
railway add
# Select "Deploy from GitHub repo"
# Configure build command: npm run build
# Configure start command: serve -s dist
```

**Result:** 
- Backend: `https://your-backend.railway.app`
- Frontend: `https://your-frontend.railway.app`

---

## 🎨 **OPTION 6: RENDER (Production-Ready)**

### Full-Stack Deployment

**1. Create `render.yaml`:**

```yaml
services:
  - type: web
    name: voxy-backend
    env: python
    buildCommand: pip install -r backend/requirements.txt
    startCommand: uvicorn backend.app.main:app --host 0.0.0.0 --port $PORT
    healthCheckPath: /health
    envVars:
      - key: ANTHROPIC_API_KEY
        sync: false
      - key: DATABASE_URL
        fromDatabase:
          name: voxy-db
          property: connectionString
      - key: REDIS_URL
        fromService:
          type: redis
          name: voxy-redis
          property: connectionString

  - type: web
    name: voxy-frontend
    env: node
    buildCommand: npm ci && npm run build
    staticPublishPath: ./dist
    headers:
      - path: /*
        name: X-Frame-Options
        value: DENY
      - path: /*
        name: X-Voxy-Privacy
        value: enabled

databases:
  - name: voxy-db
    databaseName: voxy
    user: voxy

services:
  - type: redis
    name: voxy-redis
    maxmemoryPolicy: allkeys-lru
```

**Result:**
- Backend: `https://voxy-backend.onrender.com`
- Frontend: `https://voxy-frontend.onrender.com`

---

## 🌊 **OPTION 7: DIGITALOCEAN APP PLATFORM**

### App Spec Configuration

Create `.do/app.yaml`:

```yaml
name: voxy
services:
- name: backend
  source_dir: backend
  github:
    repo: your-username/voxy
    branch: main
  run_command: uvicorn app.main:app --host 0.0.0.0 --port $PORT
  environment_slug: python
  instance_count: 1
  instance_size_slug: basic-xxs
  health_check:
    http_path: /health
  envs:
  - key: ANTHROPIC_API_KEY
    scope: RUN_TIME
    type: SECRET
  - key: DATABASE_URL
    scope: RUN_TIME
    type: SECRET

- name: frontend
  source_dir: /
  github:
    repo: your-username/voxy
    branch: main
  build_command: npm ci && npm run build
  run_command: npx serve -s dist -p $PORT
  environment_slug: node-js
  instance_count: 1
  instance_size_slug: basic-xxs

databases:
- name: voxy-db
  engine: PG
  version: "13"
  size: basic-xs

- name: voxy-redis
  engine: REDIS
  version: "7"
  size: basic-xs
```

**Deployment:**

```bash
# Install doctl CLI
# Deploy
doctl apps create --spec .do/app.yaml
```

---

## ☁️ **OPTION 8: AWS (Enterprise Production)**

### Infrastructure as Code

Create `aws-infrastructure.yml` (CloudFormation):

```yaml
AWSTemplateFormatVersion: '2010-09-09'
Description: 'Voxy AI Podcast Platform - Production Infrastructure'

Parameters:
  AnthropicApiKey:
    Type: String
    NoEcho: true
    Description: Anthropic API Key

Resources:
  # ECS Cluster
  VoxyCluster:
    Type: AWS::ECS::Cluster
    Properties:
      ClusterName: voxy-production

  # RDS PostgreSQL
  VoxyDatabase:
    Type: AWS::RDS::DBInstance
    Properties:
      DBInstanceIdentifier: voxy-db
      DBInstanceClass: db.t3.micro
      Engine: postgres
      EngineVersion: '15.4'
      MasterUsername: voxy
      MasterUserPassword: !Ref DatabasePassword
      AllocatedStorage: 20
      StorageType: gp2

  # ElastiCache Redis
  VoxyRedis:
    Type: AWS::ElastiCache::CacheCluster
    Properties:
      CacheNodeType: cache.t3.micro
      Engine: redis
      NumCacheNodes: 1

  # Application Load Balancer
  VoxyALB:
    Type: AWS::ElasticLoadBalancingV2::LoadBalancer
    Properties:
      Name: voxy-alb
      Scheme: internet-facing
      Type: application

  # ECS Service for Backend
  VoxyBackendService:
    Type: AWS::ECS::Service
    Properties:
      Cluster: !Ref VoxyCluster
      TaskDefinition: !Ref VoxyBackendTask
      DesiredCount: 2
      LaunchType: FARGATE

  # CloudFront for Frontend
  VoxyCloudFront:
    Type: AWS::CloudFront::Distribution
    Properties:
      DistributionConfig:
        Origins:
        - DomainName: !GetAtt VoxyS3Bucket.DomainName
          Id: S3Origin
          S3OriginConfig:
            OriginAccessIdentity: !Ref OriginAccessIdentity
        DefaultCacheBehavior:
          TargetOriginId: S3Origin
          ViewerProtocolPolicy: redirect-to-https
```

### Deployment Commands

```bash
# Deploy infrastructure
aws cloudformation deploy \
  --template-file aws-infrastructure.yml \
  --stack-name voxy-production \
  --parameter-overrides AnthropicApiKey=your_key_here \
  --capabilities CAPABILITY_IAM

# Deploy application
aws ecs update-service \
  --cluster voxy-production \
  --service voxy-backend \
  --force-new-deployment
```

---

## 🔧 **ENVIRONMENT CONFIGURATION**

### Frontend Environment Variables

```bash
# Required for all deployments
VITE_API_URL=https://your-backend-url.com
VITE_PRIVACY_MODE=enabled
VITE_MOZILLA_SERVICES=true
VITE_OPENAI_BLOCKED=true

# Optional
VITE_SENTRY_DSN=your_sentry_dsn
VITE_ANALYTICS_ID=your_analytics_id
```

### Backend Environment Variables

```bash
# Required
ANTHROPIC_API_KEY=your_anthropic_api_key
DATABASE_URL=postgresql://user:pass@host:port/db
SECRET_KEY=your_secret_key

# Optional
REDIS_URL=redis://host:port/0
SENTRY_DSN=your_sentry_dsn
ENVIRONMENT=production
```

---

## 📊 **COST COMPARISON**

| Platform | Frontend | Backend | Database | Total/Month |
|----------|----------|---------|----------|-------------|
| **Netlify + Railway** | Free | $5 | $5 | $10 |
| **Vercel + Render** | Free | $7 | $7 | $14 |
| **GitHub Pages + Railway** | Free | $5 | $5 | $10 |
| **DigitalOcean** | $5 | $5 | $15 | $25 |
| **AWS (Small)** | $1 | $15 | $15 | $31 |
| **GCP (Small)** | $1 | $12 | $12 | $25 |

---

## 🚀 **RECOMMENDED DEPLOYMENT PATHS**

### **For Demos/MVPs**
1. **Netlify** (frontend) + **Railway** (backend)
2. **Vercel** (frontend) + **Render** (backend)
3. **GitHub Pages** (frontend only with mocked backend)

### **For Production**
1. **DigitalOcean App Platform** (full-stack)
2. **Render** (full-stack with managed services)
3. **AWS/GCP** (enterprise with custom infrastructure)

### **For Development**
1. **Railway** (easiest full-stack setup)
2. **Local Docker** (complete control)
3. **Render** (staging environment)

---

## 🔐 **SECURITY CONSIDERATIONS**

### SSL/HTTPS
- All platforms provide free SSL certificates
- Configure HTTPS redirects
- Set security headers

### Environment Variables
- Never commit API keys to git
- Use platform secret management
- Rotate keys regularly

### CORS Configuration
```javascript
// Backend CORS settings
ALLOWED_ORIGINS = [
  "https://your-frontend.netlify.app",
  "https://your-frontend.vercel.app",
  "https://yourdomain.com"
]
```

### Rate Limiting
- Configure rate limiting at platform level
- Use CDN for static assets
- Implement API rate limiting

---

## 📈 **SCALING STRATEGIES**

### Horizontal Scaling
- Multiple backend instances
- Load balancer configuration
- Database read replicas

### Vertical Scaling
- Increase instance sizes
- Optimize database performance
- CDN for global distribution

### Monitoring
- Application performance monitoring
- Error tracking with Sentry
- Custom metrics and alerts

---

## 🎯 **QUICK START RECOMMENDATIONS**

### **Fastest Demo (5 minutes)**
```bash
# Deploy to Netlify
npm run build
npx netlify-cli deploy --prod --dir=dist
```

### **Full-Stack Demo (15 minutes)**
```bash
# Deploy to Railway
git push origin main
# Connect to Railway dashboard
# Add PostgreSQL and Redis
# Deploy backend and frontend
```

### **Production Ready (1 hour)**
```bash
# Deploy to DigitalOcean App Platform
# Configure custom domain
# Set up monitoring
# Configure backups
```

Each deployment option includes the complete Voxy application with all features, privacy controls, and AI integrations intact.