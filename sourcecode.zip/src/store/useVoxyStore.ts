import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export type ProcessingMode = 'cloud' | 'local' | 'hybrid';
export type PrivacyLevel = 'maximum' | 'balanced' | 'performance';

export interface VoiceProfile {
  id: string;
  name: string;
  language: string;
  gender: 'male' | 'female' | 'other';
  accent?: string;
  description?: string;
  sampleUrl?: string;
}

export interface Persona {
  id: string;
  name: string;
  role: string;
  personality: string;
  voiceProfile?: VoiceProfile;
  description: string;
}

export interface Project {
  id: string;
  name: string;
  description: string;
  createdAt: Date;
  updatedAt: Date;
  documents: Document[];
  generatedAudio?: string;
  transcript?: string;
  citations?: Citation[];
  processingMode: ProcessingMode;
  privacyLevel: PrivacyLevel;
}

export interface Document {
  id: string;
  name: string;
  type: string;
  size: number;
  content: string;
  uploadedAt: Date;
}

export interface Citation {
  id: string;
  text: string;
  source: string;
  page?: number;
  timestamp?: number;
}

export interface GenerationSettings {
  duration: number; // in minutes
  tone: 'educational' | 'entertaining' | 'balanced' | 'debate';
  personas: Persona[];
  focusAreas?: string[];
  includeIntro: boolean;
  includeConclusion: boolean;
  language: string;
}

interface VoxyStore {
  // User preferences
  processingMode: ProcessingMode;
  privacyLevel: PrivacyLevel;
  
  // Mozilla integration status
  deepSpeechReady: boolean;
  commonVoiceProfiles: VoiceProfile[];
  
  // OpenAI blocking
  blockedServices: string[];
  
  // Project state
  currentProject: Project | null;
  projects: Project[];
  generationProgress: number;
  isGenerating: boolean;
  
  // Available personas
  availablePersonas: Persona[];
  
  // Actions
  setProcessingMode: (mode: ProcessingMode) => void;
  setPrivacyLevel: (level: PrivacyLevel) => void;
  setCurrentProject: (project: Project | null) => void;
  addProject: (project: Project) => void;
  updateProject: (id: string, updates: Partial<Project>) => void;
  deleteProject: (id: string) => void;
  setGenerationProgress: (progress: number) => void;
  setIsGenerating: (generating: boolean) => void;
  initializeMozillaServices: () => Promise<void>;
  validateNoOpenAI: () => boolean;
  addDocument: (projectId: string, document: Document) => void;
  removeDocument: (projectId: string, documentId: string) => void;
}

// Default personas with Mozilla/privacy focus
const defaultPersonas: Persona[] = [
  {
    id: 'dr-sarah-chen',
    name: 'Dr. Sarah Chen',
    role: 'Subject Matter Expert',
    personality: 'Analytical, thorough, and precise. Focuses on accuracy and evidence-based insights.',
    description: 'A research scientist who breaks down complex topics with clarity and depth.',
  },
  {
    id: 'marcus-rivera',
    name: 'Marcus Rivera',
    role: 'Investigative Journalist',
    personality: 'Curious, probing, and skeptical. Asks tough questions and seeks the truth.',
    description: 'An experienced journalist who challenges assumptions and digs deeper.',
  },
  {
    id: 'alex-kim',
    name: 'Alex Kim',
    role: 'Curious Student',
    personality: 'Enthusiastic, inquisitive, and relatable. Asks questions the audience might have.',
    description: 'A bright student who represents the audience\'s perspective and learning journey.',
  },
  {
    id: 'dr-james-wright',
    name: 'Dr. James Wright',
    role: 'Critical Analyst',
    personality: 'Methodical, logical, and balanced. Evaluates arguments from multiple angles.',
    description: 'A philosopher who examines ideas critically and presents balanced viewpoints.',
  },
  {
    id: 'maya-patel',
    name: 'Maya Patel',
    role: 'Creative Storyteller',
    personality: 'Imaginative, engaging, and empathetic. Makes content accessible and memorable.',
    description: 'A creative writer who transforms complex ideas into compelling narratives.',
  },
];

export const useVoxyStore = create<VoxyStore>()(
  persist(
    (set, get) => ({
      // Initial state
      processingMode: 'balanced' as ProcessingMode,
      privacyLevel: 'balanced' as PrivacyLevel,
      deepSpeechReady: false,
      commonVoiceProfiles: [],
      blockedServices: ['openai', 'gpt', 'chatgpt', 'dall-e', 'whisper'],
      currentProject: null,
      projects: [],
      generationProgress: 0,
      isGenerating: false,
      availablePersonas: defaultPersonas,

      // Actions
      setProcessingMode: (mode) => set({ processingMode: mode }),
      setPrivacyLevel: (level) => set({ privacyLevel: level }),
      setCurrentProject: (project) => set({ currentProject: project }),
      
      addProject: (project) => set((state) => ({
        projects: [...state.projects, project],
      })),
      
      updateProject: (id, updates) => set((state) => ({
        projects: state.projects.map(p => 
          p.id === id ? { ...p, ...updates, updatedAt: new Date() } : p
        ),
        currentProject: state.currentProject?.id === id 
          ? { ...state.currentProject, ...updates, updatedAt: new Date() }
          : state.currentProject,
      })),
      
      deleteProject: (id) => set((state) => ({
        projects: state.projects.filter(p => p.id !== id),
        currentProject: state.currentProject?.id === id ? null : state.currentProject,
      })),
      
      setGenerationProgress: (progress) => set({ generationProgress: progress }),
      setIsGenerating: (generating) => set({ isGenerating: generating }),
      
      initializeMozillaServices: async () => {
        // This would initialize Mozilla DeepSpeech and TTS services
        // For now, we'll simulate the initialization
        set({ deepSpeechReady: true });
      },
      
      validateNoOpenAI: () => {
        const { blockedServices } = get();
        // Check if any OpenAI services are being used
        // This is a placeholder - in a real app, this would scan dependencies
        return blockedServices.length > 0;
      },
      
      addDocument: (projectId, document) => set((state) => ({
        projects: state.projects.map(p => 
          p.id === projectId 
            ? { ...p, documents: [...p.documents, document], updatedAt: new Date() }
            : p
        ),
        currentProject: state.currentProject?.id === projectId
          ? { ...state.currentProject, documents: [...state.currentProject.documents, document], updatedAt: new Date() }
          : state.currentProject,
      })),
      
      removeDocument: (projectId, documentId) => set((state) => ({
        projects: state.projects.map(p => 
          p.id === projectId 
            ? { ...p, documents: p.documents.filter(d => d.id !== documentId), updatedAt: new Date() }
            : p
        ),
        currentProject: state.currentProject?.id === projectId
          ? { ...state.currentProject, documents: state.currentProject.documents.filter(d => d.id !== documentId), updatedAt: new Date() }
          : state.currentProject,
      })),
    }),
    {
      name: 'voxy-store',
      partialize: (state) => ({
        processingMode: state.processingMode,
        privacyLevel: state.privacyLevel,
        projects: state.projects,
        availablePersonas: state.availablePersonas,
      }),
    }
  )
);