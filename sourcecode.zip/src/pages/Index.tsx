import { useSeoMeta } from '@unhead/react';
import { LandingPage } from '@/components/LandingPage';

const Index = () => {
  useSeoMeta({
    title: 'Voxy - AI-Powered Podcast Generation Platform',
    description: 'Transform documents into engaging podcast conversations using Anthropic Claude AI and Mozilla speech technologies. Privacy-first, open-source, and built entirely through AI-driven development.',
  });

  return <LandingPage />;
};

export default Index;
