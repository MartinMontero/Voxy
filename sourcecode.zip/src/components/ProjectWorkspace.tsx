import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';
import { 
  FileText, 
  Users, 
  Settings, 
  Play, 
  Zap,
  Shield,
  Globe,
  Cpu,
  Clock,
  ArrowLeft,
  Trash2,
  AlertTriangle
} from 'lucide-react';
import { useVoxyStore, type Persona, type GenerationSettings } from '@/store/useVoxyStore';
import { useNavigate, useParams } from 'react-router-dom';
import { FileUploader } from './FileUploader';
import { PersonaSelector } from './PersonaSelector';
import { AudioPlayer } from './AudioPlayer';

const fadeInUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.6 }
};

export function ProjectWorkspace() {
  const { projectId } = useParams<{ projectId: string }>();
  const navigate = useNavigate();
  const { 
    projects, 
    currentProject, 
    setCurrentProject,
    generationProgress,
    isGenerating,
    setIsGenerating,
    setGenerationProgress,
    updateProject,
    deleteProject
  } = useVoxyStore();

  const [selectedPersonas, setSelectedPersonas] = useState<Persona[]>([]);
  const [generationSettings, setGenerationSettings] = useState<GenerationSettings>({
    duration: 10,
    tone: 'balanced',
    personas: [],
    includeIntro: true,
    includeConclusion: true,
    language: 'en-US'
  });

  // Load project on mount
  useEffect(() => {
    if (projectId) {
      const project = projects.find(p => p.id === projectId);
      if (project) {
        setCurrentProject(project);
      } else {
        navigate('/dashboard');
      }
    }
  }, [projectId, projects, setCurrentProject, navigate]);

  const handlePersonaToggle = (persona: Persona) => {
    setSelectedPersonas(prev => {
      const isSelected = prev.some(p => p.id === persona.id);
      if (isSelected) {
        return prev.filter(p => p.id !== persona.id);
      } else {
        return [...prev, persona];
      }
    });
  };

  const handleGeneratePodcast = async () => {
    if (!currentProject || selectedPersonas.length === 0) return;

    setIsGenerating(true);
    setGenerationProgress(0);

    try {
      // Simulate generation process
      const steps = [
        'Analyzing documents...',
        'Generating conversation outline...',
        'Creating dialogue with Anthropic Claude...',
        'Synthesizing speech with Mozilla TTS...',
        'Mixing audio segments...',
        'Finalizing podcast...'
      ];

      for (let i = 0; i < steps.length; i++) {
        await new Promise(resolve => setTimeout(resolve, 2000));
        setGenerationProgress(((i + 1) / steps.length) * 100);
      }

      // Simulate generated content
      const generatedAudio = 'https://example.com/generated-podcast.mp3';
      const transcript = `Welcome to this AI-generated podcast discussion about your documents.

Dr. Sarah Chen: Today we're exploring the fascinating content from the uploaded documents. The key insights reveal...

Marcus Rivera: That's a compelling point, Sarah. What strikes me most is how the data suggests...

Alex Kim: I'm curious about something - could you explain more about the implications of...

Dr. James Wright: From a critical perspective, we should also consider the limitations...

Maya Patel: What I find most engaging about this topic is how it connects to everyday experiences...

[Conversation continues with natural back-and-forth discussion, incorporating citations and insights from the source documents]`;

      const citations = [
        {
          id: '1',
          text: 'Key finding about AI development trends',
          source: 'Document 1, Page 3',
          timestamp: 45
        },
        {
          id: '2',
          text: 'Statistical data on market growth',
          source: 'Document 2, Page 7',
          timestamp: 120
        }
      ];

      // Update project with generated content
      updateProject(currentProject.id, {
        generatedAudio,
        transcript,
        citations
      });

    } catch (error) {
      console.error('Generation failed:', error);
    } finally {
      setIsGenerating(false);
      setGenerationProgress(0);
    }
  };

  const handleDeleteProject = () => {
    if (currentProject) {
      deleteProject(currentProject.id);
      navigate('/dashboard');
    }
  };

  const getProcessingModeInfo = () => {
    if (!currentProject) return null;

    switch (currentProject.processingMode) {
      case 'cloud':
        return {
          icon: <Globe className="h-4 w-4" />,
          label: 'Cloud Processing',
          description: 'Using Anthropic Claude + Mozilla services',
          color: 'text-blue-600'
        };
      case 'local':
        return {
          icon: <Shield className="h-4 w-4" />,
          label: 'Local Processing',
          description: 'All processing happens on your device',
          color: 'text-green-600'
        };
      case 'hybrid':
        return {
          icon: <Cpu className="h-4 w-4" />,
          label: 'Hybrid Processing',
          description: 'Balanced approach with privacy controls',
          color: 'text-purple-600'
        };
    }
  };

  if (!currentProject) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-background to-primary/5 flex items-center justify-center">
        <div className="text-center">
          <AlertTriangle className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
          <h2 className="text-2xl font-semibold mb-2">Project Not Found</h2>
          <p className="text-muted-foreground mb-6">
            The project you're looking for doesn't exist or has been deleted.
          </p>
          <Button onClick={() => navigate('/dashboard')}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Dashboard
          </Button>
        </div>
      </div>
    );
  }

  const processingInfo = getProcessingModeInfo();

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-primary/5">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <motion.div 
          className="flex items-center justify-between mb-8"
          initial="initial"
          animate="animate"
          variants={fadeInUp}
        >
          <div className="flex items-center space-x-4">
            <Button variant="outline" onClick={() => navigate('/dashboard')}>
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back
            </Button>
            <div>
              <h1 className="text-3xl font-bold">{currentProject.name}</h1>
              <div className="flex items-center space-x-4 mt-2">
                {processingInfo && (
                  <Badge variant="outline" className={processingInfo.color}>
                    {processingInfo.icon}
                    <span className="ml-1">{processingInfo.label}</span>
                  </Badge>
                )}
                <Badge variant="outline">
                  <Shield className="h-3 w-3 mr-1" />
                  {currentProject.privacyLevel}
                </Badge>
              </div>
            </div>
          </div>
          
          <Button 
            variant="destructive" 
            size="sm"
            onClick={handleDeleteProject}
          >
            <Trash2 className="h-4 w-4 mr-2" />
            Delete Project
          </Button>
        </motion.div>

        {/* Generation Progress */}
        {isGenerating && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-8"
          >
            <Card className="border-primary/20 bg-primary/5">
              <CardContent className="p-6">
                <div className="flex items-center space-x-4">
                  <Zap className="h-6 w-6 text-primary animate-pulse" />
                  <div className="flex-1">
                    <h3 className="font-semibold mb-2">Generating Your Podcast...</h3>
                    <Progress value={generationProgress} className="mb-2" />
                    <p className="text-sm text-muted-foreground">
                      {processingInfo?.description} • {Math.round(generationProgress)}% complete
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            <Tabs defaultValue="documents" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="documents" className="flex items-center">
                  <FileText className="h-4 w-4 mr-2" />
                  Documents
                </TabsTrigger>
                <TabsTrigger value="personas" className="flex items-center">
                  <Users className="h-4 w-4 mr-2" />
                  Personas
                </TabsTrigger>
                <TabsTrigger value="settings" className="flex items-center">
                  <Settings className="h-4 w-4 mr-2" />
                  Settings
                </TabsTrigger>
              </TabsList>

              <TabsContent value="documents" className="space-y-6">
                <motion.div variants={fadeInUp}>
                  <FileUploader projectId={currentProject.id} />
                </motion.div>

                {currentProject.documents.length > 0 && (
                  <motion.div variants={fadeInUp}>
                    <Card>
                      <CardHeader>
                        <CardTitle>Uploaded Documents</CardTitle>
                        <CardDescription>
                          {currentProject.documents.length} document(s) ready for processing
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-3">
                          {currentProject.documents.map((doc) => (
                            <div key={doc.id} className="flex items-center justify-between p-3 border rounded-lg">
                              <div className="flex items-center space-x-3">
                                <FileText className="h-5 w-5 text-muted-foreground" />
                                <div>
                                  <p className="font-medium">{doc.name}</p>
                                  <p className="text-sm text-muted-foreground">
                                    {(doc.size / 1024 / 1024).toFixed(1)} MB • {doc.type}
                                  </p>
                                </div>
                              </div>
                              <Badge variant="outline">Ready</Badge>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                )}
              </TabsContent>

              <TabsContent value="personas" className="space-y-6">
                <motion.div variants={fadeInUp}>
                  <PersonaSelector
                    selectedPersonas={selectedPersonas}
                    onPersonaToggle={handlePersonaToggle}
                    maxSelection={3}
                  />
                </motion.div>
              </TabsContent>

              <TabsContent value="settings" className="space-y-6">
                <motion.div variants={fadeInUp}>
                  <Card>
                    <CardHeader>
                      <CardTitle>Generation Settings</CardTitle>
                      <CardDescription>
                        Configure how your podcast will be generated
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      <div>
                        <Label htmlFor="duration">Duration (minutes)</Label>
                        <Slider
                          value={[generationSettings.duration]}
                          onValueChange={(value) => setGenerationSettings(prev => ({ ...prev, duration: value[0] }))}
                          max={20}
                          min={5}
                          step={1}
                          className="mt-2"
                        />
                        <p className="text-sm text-muted-foreground mt-1">
                          {generationSettings.duration} minutes
                        </p>
                      </div>

                      <div>
                        <Label htmlFor="tone">Conversation Tone</Label>
                        <Select 
                          value={generationSettings.tone} 
                          onValueChange={(value) => setGenerationSettings(prev => ({ ...prev, tone: value as 'educational' | 'entertaining' | 'balanced' | 'debate' }))}
                        >
                          <SelectTrigger className="mt-2">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="educational">Educational</SelectItem>
                            <SelectItem value="entertaining">Entertaining</SelectItem>
                            <SelectItem value="balanced">Balanced</SelectItem>
                            <SelectItem value="debate">Debate Style</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <Label htmlFor="language">Language</Label>
                        <Select 
                          value={generationSettings.language} 
                          onValueChange={(value) => setGenerationSettings(prev => ({ ...prev, language: value }))}
                        >
                          <SelectTrigger className="mt-2">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="en-US">English (US)</SelectItem>
                            <SelectItem value="en-GB">English (UK)</SelectItem>
                            <SelectItem value="es-ES">Spanish</SelectItem>
                            <SelectItem value="fr-FR">French</SelectItem>
                            <SelectItem value="de-DE">German</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <Separator />

                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <div>
                            <Label htmlFor="intro">Include Introduction</Label>
                            <p className="text-sm text-muted-foreground">
                              Add a brief introduction to the podcast
                            </p>
                          </div>
                          <Switch
                            id="intro"
                            checked={generationSettings.includeIntro}
                            onCheckedChange={(checked) => setGenerationSettings(prev => ({ ...prev, includeIntro: checked }))}
                          />
                        </div>

                        <div className="flex items-center justify-between">
                          <div>
                            <Label htmlFor="conclusion">Include Conclusion</Label>
                            <p className="text-sm text-muted-foreground">
                              Add a summary and conclusion
                            </p>
                          </div>
                          <Switch
                            id="conclusion"
                            checked={generationSettings.includeConclusion}
                            onCheckedChange={(checked) => setGenerationSettings(prev => ({ ...prev, includeConclusion: checked }))}
                          />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              </TabsContent>
            </Tabs>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Generation Panel */}
            <motion.div variants={fadeInUp}>
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Zap className="h-5 w-5 mr-2" />
                    Generate Podcast
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Documents:</span>
                      <span className={currentProject.documents.length > 0 ? 'text-green-600' : 'text-muted-foreground'}>
                        {currentProject.documents.length}
                      </span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Personas:</span>
                      <span className={selectedPersonas.length > 0 ? 'text-green-600' : 'text-muted-foreground'}>
                        {selectedPersonas.length}
                      </span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Duration:</span>
                      <span>{generationSettings.duration} min</span>
                    </div>
                  </div>

                  <Button 
                    className="w-full" 
                    onClick={handleGeneratePodcast}
                    disabled={isGenerating || currentProject.documents.length === 0 || selectedPersonas.length === 0}
                  >
                    {isGenerating ? (
                      <>
                        <Clock className="h-4 w-4 mr-2 animate-spin" />
                        Generating...
                      </>
                    ) : (
                      <>
                        <Play className="h-4 w-4 mr-2" />
                        Generate Podcast
                      </>
                    )}
                  </Button>

                  {processingInfo && (
                    <div className="text-xs text-muted-foreground text-center">
                      {processingInfo.description}
                    </div>
                  )}
                </CardContent>
              </Card>
            </motion.div>

            {/* Audio Player */}
            <motion.div variants={fadeInUp}>
              <AudioPlayer
                audioUrl={currentProject.generatedAudio}
                transcript={currentProject.transcript}
                citations={currentProject.citations}
                title={currentProject.name}
              />
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
}