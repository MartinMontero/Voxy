import { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { 
  Plus, 
  FileText, 
  Clock, 
  Settings, 
  Trash2, 
  Play,
  Shield,
  Cpu,
  Globe,
  Users
} from 'lucide-react';
import { useVoxyStore, type Project, type ProcessingMode, type PrivacyLevel } from '@/store/useVoxyStore';
import { useNavigate } from 'react-router-dom';
import { format } from 'date-fns';

const fadeInUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.6 }
};

export function Dashboard() {
  const navigate = useNavigate();
  const { 
    projects, 
    addProject, 
    deleteProject, 
    setCurrentProject,
    processingMode,
    privacyLevel,
    setProcessingMode,
    setPrivacyLevel
  } = useVoxyStore();

  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [newProject, setNewProject] = useState({
    name: '',
    description: '',
    processingMode: processingMode as ProcessingMode,
    privacyLevel: privacyLevel as PrivacyLevel
  });

  const handleCreateProject = () => {
    if (!newProject.name.trim()) return;

    const project: Project = {
      id: crypto.randomUUID(),
      name: newProject.name,
      description: newProject.description,
      createdAt: new Date(),
      updatedAt: new Date(),
      documents: [],
      processingMode: newProject.processingMode as ProcessingMode,
      privacyLevel: newProject.privacyLevel as PrivacyLevel
    };

    addProject(project);
    setCurrentProject(project);
    setIsCreateDialogOpen(false);
    setNewProject({ name: '', description: '', processingMode, privacyLevel });
    navigate(`/project/${project.id}`);
  };

  const handleOpenProject = (project: Project) => {
    setCurrentProject(project);
    navigate(`/project/${project.id}`);
  };

  const getProcessingModeIcon = (mode: ProcessingMode) => {
    switch (mode) {
      case 'cloud': return <Globe className="h-4 w-4" />;
      case 'local': return <Shield className="h-4 w-4" />;
      case 'hybrid': return <Cpu className="h-4 w-4" />;
    }
  };

  const getPrivacyLevelColor = (level: PrivacyLevel) => {
    switch (level) {
      case 'maximum': return 'bg-green-100 text-green-800 border-green-200';
      case 'balanced': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'performance': return 'bg-orange-100 text-orange-800 border-orange-200';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-primary/5">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <motion.div 
          className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8"
          initial="initial"
          animate="animate"
          variants={fadeInUp}
        >
          <div>
            <h1 className="text-3xl font-bold mb-2">Your Podcast Projects</h1>
            <p className="text-muted-foreground">
              Transform your documents into engaging conversations with AI
            </p>
          </div>
          
          <div className="flex gap-4 mt-4 md:mt-0">
            <Dialog>
              <DialogTrigger asChild>
                <Button variant="outline" size="sm">
                  <Settings className="h-4 w-4 mr-2" />
                  Settings
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Global Settings</DialogTitle>
                  <DialogDescription>
                    Configure your default processing and privacy preferences
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="processing-mode">Default Processing Mode</Label>
                    <Select value={processingMode} onValueChange={(value) => setProcessingMode(value as ProcessingMode)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="cloud">Cloud (Anthropic + Mozilla)</SelectItem>
                        <SelectItem value="local">Local (Open Source Only)</SelectItem>
                        <SelectItem value="hybrid">Hybrid (Balanced)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="privacy-level">Default Privacy Level</Label>
                    <Select value={privacyLevel} onValueChange={(value) => setPrivacyLevel(value as PrivacyLevel)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="maximum">Maximum (All Local)</SelectItem>
                        <SelectItem value="balanced">Balanced (Secure Cloud)</SelectItem>
                        <SelectItem value="performance">Performance (Optimized)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </DialogContent>
            </Dialog>

            <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  New Project
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Create New Project</DialogTitle>
                  <DialogDescription>
                    Start a new podcast generation project
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="name">Project Name</Label>
                    <Input
                      id="name"
                      placeholder="My Awesome Podcast"
                      value={newProject.name}
                      onChange={(e) => setNewProject(prev => ({ ...prev, name: e.target.value }))}
                    />
                  </div>
                  <div>
                    <Label htmlFor="description">Description (Optional)</Label>
                    <Textarea
                      id="description"
                      placeholder="Describe what this podcast will be about..."
                      value={newProject.description}
                      onChange={(e) => setNewProject(prev => ({ ...prev, description: e.target.value }))}
                    />
                  </div>
                  <div>
                    <Label htmlFor="processing-mode">Processing Mode</Label>
                    <Select 
                      value={newProject.processingMode} 
                      onValueChange={(value) => setNewProject(prev => ({ ...prev, processingMode: value as ProcessingMode }))}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="cloud">Cloud (Anthropic + Mozilla)</SelectItem>
                        <SelectItem value="local">Local (Open Source Only)</SelectItem>
                        <SelectItem value="hybrid">Hybrid (Balanced)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="privacy-level">Privacy Level</Label>
                    <Select 
                      value={newProject.privacyLevel} 
                      onValueChange={(value) => setNewProject(prev => ({ ...prev, privacyLevel: value as PrivacyLevel }))}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="maximum">Maximum (All Local)</SelectItem>
                        <SelectItem value="balanced">Balanced (Secure Cloud)</SelectItem>
                        <SelectItem value="performance">Performance (Optimized)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <Button onClick={handleCreateProject} className="w-full">
                    Create Project
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </motion.div>

        {/* Projects Grid */}
        {projects.length === 0 ? (
          <motion.div 
            className="text-center py-20"
            initial="initial"
            animate="animate"
            variants={fadeInUp}
          >
            <FileText className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
            <h2 className="text-2xl font-semibold mb-2">No projects yet</h2>
            <p className="text-muted-foreground mb-6">
              Create your first project to start generating AI-powered podcasts
            </p>
            <Button onClick={() => setIsCreateDialogOpen(true)}>
              <Plus className="h-4 w-4 mr-2" />
              Create Your First Project
            </Button>
          </motion.div>
        ) : (
          <motion.div 
            className="grid md:grid-cols-2 lg:grid-cols-3 gap-6"
            initial="initial"
            animate="animate"
            variants={{
              animate: {
                transition: {
                  staggerChildren: 0.1
                }
              }
            }}
          >
            {projects.map((project) => (
              <motion.div key={project.id} variants={fadeInUp}>
                <Card className="h-full hover:shadow-lg transition-all duration-200 cursor-pointer group">
                  <CardHeader className="pb-3">
                    <div className="flex justify-between items-start mb-2">
                      <CardTitle className="text-lg line-clamp-1 group-hover:text-primary transition-colors">
                        {project.name}
                      </CardTitle>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={(e) => {
                          e.stopPropagation();
                          deleteProject(project.id);
                        }}
                        className="opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </div>
                    
                    <div className="flex gap-2 mb-2">
                      <Badge variant="outline" className="text-xs">
                        {getProcessingModeIcon(project.processingMode)}
                        <span className="ml-1 capitalize">{project.processingMode}</span>
                      </Badge>
                      <Badge variant="outline" className={`text-xs ${getPrivacyLevelColor(project.privacyLevel)}`}>
                        <Shield className="h-3 w-3 mr-1" />
                        {project.privacyLevel}
                      </Badge>
                    </div>

                    {project.description && (
                      <CardDescription className="line-clamp-2">
                        {project.description}
                      </CardDescription>
                    )}
                  </CardHeader>

                  <CardContent className="pt-0">
                    <div className="flex items-center justify-between text-sm text-muted-foreground mb-4">
                      <div className="flex items-center">
                        <FileText className="h-4 w-4 mr-1" />
                        {project.documents.length} documents
                      </div>
                      <div className="flex items-center">
                        <Clock className="h-4 w-4 mr-1" />
                        {format(project.updatedAt, 'MMM d')}
                      </div>
                    </div>

                    <div className="flex gap-2">
                      <Button 
                        className="flex-1" 
                        onClick={() => handleOpenProject(project)}
                      >
                        <Users className="h-4 w-4 mr-2" />
                        Open
                      </Button>
                      {project.generatedAudio && (
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation();
                            // TODO: Play audio
                          }}
                        >
                          <Play className="h-4 w-4" />
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        )}

        {/* Quick Stats */}
        {projects.length > 0 && (
          <motion.div 
            className="mt-12 grid grid-cols-2 md:grid-cols-4 gap-4"
            initial="initial"
            animate="animate"
            variants={fadeInUp}
          >
            <Card>
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-primary">{projects.length}</div>
                <div className="text-sm text-muted-foreground">Total Projects</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-accent">
                  {projects.reduce((acc, p) => acc + p.documents.length, 0)}
                </div>
                <div className="text-sm text-muted-foreground">Documents</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-blue-600">
                  {projects.filter(p => p.generatedAudio).length}
                </div>
                <div className="text-sm text-muted-foreground">Generated</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-green-600">
                  {projects.filter(p => p.privacyLevel === 'maximum').length}
                </div>
                <div className="text-sm text-muted-foreground">Private</div>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </div>
    </div>
  );
}