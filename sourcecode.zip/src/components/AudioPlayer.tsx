import { useEffect, useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Slider } from '@/components/ui/slider';
import { 
  Play, 
  Pause, 
  SkipBack, 
  SkipForward, 
  Volume2, 
  VolumeX,
  Download,
  Share,
  FileText,
  Clock,
  Mic
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface AudioPlayerProps {
  audioUrl?: string;
  transcript?: string;
  citations?: Array<{
    id: string;
    text: string;
    source: string;
    timestamp?: number;
  }>;
  title?: string;
  duration?: number;
  className?: string;
}

interface WaveformData {
  peaks: number[];
  duration: number;
}

export function AudioPlayer({ 
  audioUrl, 
  transcript, 
  citations = [], 
  title = "Generated Podcast",
  duration = 0,
  className 
}: AudioPlayerProps) {
  const audioRef = useRef<HTMLAudioElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [volume, setVolume] = useState(1);
  const [isMuted, setIsMuted] = useState(false);
  const [waveformData, setWaveformData] = useState<WaveformData | null>(null);
  const [showTranscript, setShowTranscript] = useState(false);

  // Simulate waveform data generation
  useEffect(() => {
    if (audioUrl) {
      // Generate simulated waveform data for demo purposes
      const peaks = Array.from({ length: 200 }, () => Math.random() * 0.8 + 0.1);
      setWaveformData({ peaks, duration: duration || 600 }); // 10 minutes default
    }
  }, [audioUrl, duration]);

  // Draw waveform
  useEffect(() => {
    if (!waveformData || !canvasRef.current) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const { width, height } = canvas;
    const { peaks } = waveformData;

    ctx.clearRect(0, 0, width, height);

    // Draw waveform
    const barWidth = width / peaks.length;
    const progress = currentTime / (waveformData.duration || 1);

    peaks.forEach((peak, index) => {
      const barHeight = peak * height * 0.8;
      const x = index * barWidth;
      const y = (height - barHeight) / 2;

      // Color based on progress
      const isPlayed = index / peaks.length < progress;
      ctx.fillStyle = isPlayed ? 'hsl(var(--primary))' : 'hsl(var(--muted-foreground))';
      ctx.fillRect(x, y, barWidth - 1, barHeight);
    });

    // Draw progress line
    const progressX = progress * width;
    ctx.strokeStyle = 'hsl(var(--primary))';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(progressX, 0);
    ctx.lineTo(progressX, height);
    ctx.stroke();
  }, [waveformData, currentTime]);

  const handlePlayPause = () => {
    if (!audioRef.current) return;

    if (isPlaying) {
      audioRef.current.pause();
    } else {
      audioRef.current.play();
    }
    setIsPlaying(!isPlaying);
  };

  const handleTimeUpdate = () => {
    if (audioRef.current) {
      setCurrentTime(audioRef.current.currentTime);
    }
  };

  const handleSeek = (value: number[]) => {
    if (audioRef.current && waveformData) {
      const newTime = (value[0] / 100) * waveformData.duration;
      audioRef.current.currentTime = newTime;
      setCurrentTime(newTime);
    }
  };

  const handleVolumeChange = (value: number[]) => {
    const newVolume = value[0] / 100;
    setVolume(newVolume);
    if (audioRef.current) {
      audioRef.current.volume = newVolume;
    }
    setIsMuted(newVolume === 0);
  };

  const toggleMute = () => {
    if (audioRef.current) {
      if (isMuted) {
        audioRef.current.volume = volume;
        setIsMuted(false);
      } else {
        audioRef.current.volume = 0;
        setIsMuted(true);
      }
    }
  };

  const skip = (seconds: number) => {
    if (audioRef.current) {
      audioRef.current.currentTime += seconds;
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleDownload = () => {
    if (audioUrl) {
      const a = document.createElement('a');
      a.href = audioUrl;
      a.download = `${title}.mp3`;
      a.click();
    }
  };

  const handleShare = async () => {
    if (navigator.share && audioUrl) {
      try {
        await navigator.share({
          title: title,
          text: 'Check out this AI-generated podcast!',
          url: window.location.href
        });
      } catch {
        // Fallback to clipboard
        navigator.clipboard.writeText(window.location.href);
      }
    }
  };

  if (!audioUrl) {
    return (
      <Card className={cn('border-dashed', className)}>
        <CardContent className="py-12 text-center">
          <Mic className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-semibold mb-2">No Audio Generated Yet</h3>
          <p className="text-muted-foreground">
            Upload documents and generate your podcast to see the audio player here
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className={cn('space-y-4', className)}>
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center">
              <Mic className="h-5 w-5 mr-2" />
              {title}
            </CardTitle>
            <div className="flex items-center space-x-2">
              <Badge variant="outline" className="text-xs">
                <Clock className="h-3 w-3 mr-1" />
                {formatTime(waveformData?.duration || 0)}
              </Badge>
              <Button variant="outline" size="sm" onClick={handleDownload}>
                <Download className="h-4 w-4" />
              </Button>
              <Button variant="outline" size="sm" onClick={handleShare}>
                <Share className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardHeader>

        <CardContent className="space-y-4">
          {/* Waveform */}
          <div className="relative">
            <canvas
              ref={canvasRef}
              width={800}
              height={100}
              className="w-full h-20 bg-muted/20 rounded cursor-pointer"
              onClick={(e) => {
                if (!waveformData) return;
                const rect = e.currentTarget.getBoundingClientRect();
                const x = e.clientX - rect.left;
                const progress = x / rect.width;
                const newTime = progress * waveformData.duration;
                if (audioRef.current) {
                  audioRef.current.currentTime = newTime;
                  setCurrentTime(newTime);
                }
              }}
            />
          </div>

          {/* Controls */}
          <div className="flex items-center space-x-4">
            <Button variant="outline" size="sm" onClick={() => skip(-10)}>
              <SkipBack className="h-4 w-4" />
            </Button>
            
            <Button onClick={handlePlayPause} size="lg">
              {isPlaying ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5" />}
            </Button>
            
            <Button variant="outline" size="sm" onClick={() => skip(10)}>
              <SkipForward className="h-4 w-4" />
            </Button>

            <div className="flex-1 flex items-center space-x-4">
              <span className="text-sm font-mono">
                {formatTime(currentTime)}
              </span>
              
              <Slider
                value={[waveformData ? (currentTime / waveformData.duration) * 100 : 0]}
                onValueChange={handleSeek}
                max={100}
                step={0.1}
                className="flex-1"
              />
              
              <span className="text-sm font-mono text-muted-foreground">
                {formatTime(waveformData?.duration || 0)}
              </span>
            </div>

            <div className="flex items-center space-x-2">
              <Button variant="ghost" size="sm" onClick={toggleMute}>
                {isMuted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
              </Button>
              
              <Slider
                value={[isMuted ? 0 : volume * 100]}
                onValueChange={handleVolumeChange}
                max={100}
                step={1}
                className="w-20"
              />
            </div>
          </div>

          {/* Transcript Toggle */}
          {transcript && (
            <div className="flex justify-center">
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => setShowTranscript(!showTranscript)}
              >
                <FileText className="h-4 w-4 mr-2" />
                {showTranscript ? 'Hide' : 'Show'} Transcript
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Transcript */}
      {showTranscript && transcript && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          exit={{ opacity: 0, height: 0 }}
        >
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Transcript</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="prose prose-sm max-w-none">
                <div className="whitespace-pre-wrap text-sm leading-relaxed">
                  {transcript}
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      )}

      {/* Citations */}
      {citations.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Sources & Citations</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {citations.map((citation) => (
                <div key={citation.id} className="border-l-2 border-primary/20 pl-4">
                  <p className="text-sm font-medium">{citation.text}</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    Source: {citation.source}
                    {citation.timestamp && ` • ${formatTime(citation.timestamp)}`}
                  </p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Hidden audio element */}
      <audio
        ref={audioRef}
        src={audioUrl}
        onTimeUpdate={handleTimeUpdate}
        onEnded={() => setIsPlaying(false)}
        onLoadedMetadata={() => {
          if (audioRef.current && !duration) {
            setWaveformData(prev => prev ? {
              ...prev,
              duration: audioRef.current!.duration
            } : null);
          }
        }}
      />
    </div>
  );
}