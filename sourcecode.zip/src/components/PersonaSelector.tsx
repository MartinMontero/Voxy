import { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  Users, 
  Plus, 
  Volume2,
  Globe,
  User,
  Briefcase,
  GraduationCap,
  Search,
  Lightbulb,
  BookOpen
} from 'lucide-react';
import { useVoxyStore, type Persona, type VoiceProfile } from '@/store/useVoxyStore';
import { cn } from '@/lib/utils';

interface PersonaSelectorProps {
  selectedPersonas: Persona[];
  onPersonaToggle: (persona: Persona) => void;
  maxSelection?: number;
  className?: string;
}

const roleIcons = {
  'Subject Matter Expert': <BookOpen className="h-4 w-4" />,
  'Investigative Journalist': <Search className="h-4 w-4" />,
  'Curious Student': <GraduationCap className="h-4 w-4" />,
  'Critical Analyst': <Briefcase className="h-4 w-4" />,
  'Creative Storyteller': <Lightbulb className="h-4 w-4" />,
  'Custom': <User className="h-4 w-4" />
};

const voiceProfiles: VoiceProfile[] = [
  { id: 'en-us-female-1', name: 'Sarah', language: 'en-US', gender: 'female', accent: 'General American', description: 'Clear, professional voice' },
  { id: 'en-us-male-1', name: 'Marcus', language: 'en-US', gender: 'male', accent: 'General American', description: 'Warm, engaging voice' },
  { id: 'en-us-female-2', name: 'Alex', language: 'en-US', gender: 'female', accent: 'California', description: 'Youthful, energetic voice' },
  { id: 'en-us-male-2', name: 'James', language: 'en-US', gender: 'male', accent: 'East Coast', description: 'Authoritative, measured voice' },
  { id: 'en-us-female-3', name: 'Maya', language: 'en-US', gender: 'female', accent: 'Midwest', description: 'Creative, expressive voice' },
];

export function PersonaSelector({ selectedPersonas, onPersonaToggle, maxSelection = 3, className }: PersonaSelectorProps) {
  const { availablePersonas } = useVoxyStore();
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [newPersona, setNewPersona] = useState({
    name: '',
    role: '',
    personality: '',
    description: '',
    voiceProfile: ''
  });

  const handleCreatePersona = () => {
    if (!newPersona.name.trim() || !newPersona.role.trim()) return;

    const persona: Persona = {
      id: crypto.randomUUID(),
      name: newPersona.name,
      role: newPersona.role,
      personality: newPersona.personality,
      description: newPersona.description,
      voiceProfile: voiceProfiles.find(v => v.id === newPersona.voiceProfile)
    };

    // Add persona to available personas (demo implementation)
    console.log('Created persona:', persona);
    setIsCreateDialogOpen(false);
    setNewPersona({ name: '', role: '', personality: '', description: '', voiceProfile: '' });
  };

  const isSelected = (persona: Persona) => {
    return selectedPersonas.some(p => p.id === persona.id);
  };

  const canSelect = () => {
    return selectedPersonas.length < maxSelection;
  };

  const getPersonaInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
  };

  const playVoiceSample = (voiceProfile?: VoiceProfile) => {
    if (!voiceProfile) return;
    // Play voice sample from Common Voice dataset
    console.log('Playing voice sample for:', voiceProfile.name);
  };

  return (
    <div className={cn('space-y-6', className)}>
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold flex items-center">
            <Users className="h-5 w-5 mr-2" />
            Select Conversation Personas
          </h3>
          <p className="text-sm text-muted-foreground">
            Choose {maxSelection} characters to participate in your podcast conversation
          </p>
        </div>
        
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button variant="outline" size="sm">
              <Plus className="h-4 w-4 mr-2" />
              Create Custom
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Create Custom Persona</DialogTitle>
              <DialogDescription>
                Design a unique character for your podcast conversation
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="persona-name">Name</Label>
                <Input
                  id="persona-name"
                  placeholder="Dr. Jane Smith"
                  value={newPersona.name}
                  onChange={(e) => setNewPersona(prev => ({ ...prev, name: e.target.value }))}
                />
              </div>
              <div>
                <Label htmlFor="persona-role">Role/Expertise</Label>
                <Input
                  id="persona-role"
                  placeholder="Environmental Scientist"
                  value={newPersona.role}
                  onChange={(e) => setNewPersona(prev => ({ ...prev, role: e.target.value }))}
                />
              </div>
              <div>
                <Label htmlFor="persona-personality">Personality</Label>
                <Textarea
                  id="persona-personality"
                  placeholder="Passionate, detail-oriented, speaks with authority on climate issues..."
                  value={newPersona.personality}
                  onChange={(e) => setNewPersona(prev => ({ ...prev, personality: e.target.value }))}
                />
              </div>
              <div>
                <Label htmlFor="persona-description">Description</Label>
                <Textarea
                  id="persona-description"
                  placeholder="A leading researcher who makes complex environmental science accessible..."
                  value={newPersona.description}
                  onChange={(e) => setNewPersona(prev => ({ ...prev, description: e.target.value }))}
                />
              </div>
              <div>
                <Label htmlFor="voice-profile">Voice Profile (Mozilla Common Voice)</Label>
                <Select value={newPersona.voiceProfile} onValueChange={(value) => setNewPersona(prev => ({ ...prev, voiceProfile: value }))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a voice" />
                  </SelectTrigger>
                  <SelectContent>
                    {voiceProfiles.map((voice) => (
                      <SelectItem key={voice.id} value={voice.id}>
                        <div className="flex items-center justify-between w-full">
                          <span>{voice.name} ({voice.gender})</span>
                          <Badge variant="outline" className="ml-2 text-xs">
                            {voice.accent}
                          </Badge>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <Button onClick={handleCreatePersona} className="w-full">
                Create Persona
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {availablePersonas.map((persona) => (
          <motion.div
            key={persona.id}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            <Card 
              className={cn(
                'cursor-pointer transition-all duration-200 h-full',
                isSelected(persona) 
                  ? 'ring-2 ring-primary bg-primary/5' 
                  : 'hover:shadow-md',
                !canSelect() && !isSelected(persona) && 'opacity-50 cursor-not-allowed'
              )}
              onClick={() => {
                if (canSelect() || isSelected(persona)) {
                  onPersonaToggle(persona);
                }
              }}
            >
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-center space-x-3">
                    <Avatar className="h-10 w-10">
                      <AvatarFallback className="bg-primary/10 text-primary">
                        {getPersonaInitials(persona.name)}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <CardTitle className="text-base">{persona.name}</CardTitle>
                      <div className="flex items-center text-sm text-muted-foreground">
                        {roleIcons[persona.role as keyof typeof roleIcons] || roleIcons['Custom']}
                        <span className="ml-1">{persona.role}</span>
                      </div>
                    </div>
                  </div>
                  {isSelected(persona) && (
                    <Badge variant="default" className="text-xs">
                      Selected
                    </Badge>
                  )}
                </div>
              </CardHeader>

              <CardContent className="pt-0">
                <CardDescription className="text-sm mb-3 line-clamp-2">
                  {persona.description}
                </CardDescription>

                {persona.personality && (
                  <div className="mb-3">
                    <p className="text-xs font-medium text-muted-foreground mb-1">Personality:</p>
                    <p className="text-xs text-muted-foreground line-clamp-2">
                      {persona.personality}
                    </p>
                  </div>
                )}

                {persona.voiceProfile && (
                  <div className="flex items-center justify-between">
                    <div className="flex items-center text-xs text-muted-foreground">
                      <Globe className="h-3 w-3 mr-1" />
                      <span>{persona.voiceProfile.name} ({persona.voiceProfile.gender})</span>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={(e) => {
                        e.stopPropagation();
                        playVoiceSample(persona.voiceProfile);
                      }}
                      className="h-6 w-6 p-0"
                    >
                      <Volume2 className="h-3 w-3" />
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {selectedPersonas.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-muted/30 rounded-lg p-4"
        >
          <h4 className="font-medium mb-3">Selected Personas ({selectedPersonas.length}/{maxSelection})</h4>
          <div className="flex flex-wrap gap-2">
            {selectedPersonas.map((persona) => (
              <Badge 
                key={persona.id} 
                variant="default" 
                className="flex items-center gap-2 py-1 px-3"
              >
                <Avatar className="h-4 w-4">
                  <AvatarFallback className="text-xs bg-primary-foreground text-primary">
                    {getPersonaInitials(persona.name)}
                  </AvatarFallback>
                </Avatar>
                {persona.name}
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => onPersonaToggle(persona)}
                  className="h-4 w-4 p-0 hover:bg-primary-foreground/20"
                >
                  ×
                </Button>
              </Badge>
            ))}
          </div>
        </motion.div>
      )}
    </div>
  );
}