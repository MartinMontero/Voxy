import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Mic, 
  Shield, 
  Zap, 
  FileText, 
  Users, 
  Globe, 
  Lock,
  Cpu,
  Heart,
  ArrowRight,
  CheckCircle,
  XCircle
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const fadeInUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.6 }
};

const staggerChildren = {
  animate: {
    transition: {
      staggerChildren: 0.1
    }
  }
};

export function LandingPage() {
  const navigate = useNavigate();

  const features = [
    {
      icon: <Mic className="h-6 w-6" />,
      title: "AI-Powered Conversations",
      description: "Transform documents into engaging podcast-style dialogues using Anthropic Claude AI"
    },
    {
      icon: <Shield className="h-6 w-6" />,
      title: "Privacy-First Design",
      description: "Mozilla DeepSpeech and local processing options ensure your data stays private"
    },
    {
      icon: <Globe className="h-6 w-6" />,
      title: "100+ Languages",
      description: "Powered by Mozilla Common Voice for diverse, authentic voices worldwide"
    },
    {
      icon: <Zap className="h-6 w-6" />,
      title: "Lightning Fast",
      description: "Generate 10-minute podcasts in under 3 minutes with cloud processing"
    },
    {
      icon: <FileText className="h-6 w-6" />,
      title: "Multiple Formats",
      description: "Support for PDF, DOCX, TXT, MD, and audio transcription"
    },
    {
      icon: <Users className="h-6 w-6" />,
      title: "Dynamic Personas",
      description: "Choose from expert characters or create custom personas for your content"
    }
  ];

  const blockedServices = [
    "OpenAI GPT",
    "ChatGPT API", 
    "OpenAI Whisper",
    "DALL-E",
    "Azure OpenAI"
  ];

  const allowedServices = [
    "Anthropic Claude",
    "Mozilla DeepSpeech",
    "Mozilla TTS",
    "Common Voice",
    "Open Source LLMs"
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-primary/5">
      {/* Hero Section */}
      <motion.section 
        className="container mx-auto px-4 py-20 text-center"
        initial="initial"
        animate="animate"
        variants={staggerChildren}
      >
        <motion.div variants={fadeInUp} className="mb-6">
          <Badge variant="outline" className="mb-4 border-primary/20 text-primary">
            <Heart className="h-3 w-3 mr-1" />
            AI-Powered • Privacy-First • Open Source
          </Badge>
          <h1 className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent mb-6">
            Transform Documents into
            <br />
            Engaging Podcasts
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto mb-8">
            Voxy uses Anthropic Claude AI and Mozilla speech technologies to convert your documents 
            into natural, engaging podcast conversations. Built entirely through AI-driven development 
            with complete privacy protection.
          </p>
        </motion.div>

        <motion.div variants={fadeInUp} className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
          <Button 
            size="lg" 
            className="text-lg px-8 py-6"
            onClick={() => navigate('/dashboard')}
          >
            Start Creating
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
          <Button 
            variant="outline" 
            size="lg" 
            className="text-lg px-8 py-6"
            onClick={() => navigate('/demo')}
          >
            <Mic className="mr-2 h-5 w-5" />
            Listen to Demo
          </Button>
        </motion.div>

        {/* AI Ethics Notice */}
        <motion.div variants={fadeInUp}>
          <Card className="max-w-4xl mx-auto border-accent/20 bg-accent/5">
            <CardContent className="p-6">
              <div className="flex items-center justify-center mb-4">
                <Cpu className="h-6 w-6 text-accent mr-2" />
                <h3 className="text-lg font-semibold">100% AI-Generated Platform</h3>
              </div>
              <p className="text-muted-foreground">
                This entire platform was built using Anthropic Claude AI with zero manual coding. 
                We explicitly reject OpenAI products in favor of ethical, open-source alternatives.
              </p>
            </CardContent>
          </Card>
        </motion.div>
      </motion.section>

      {/* Features Grid */}
      <motion.section 
        className="container mx-auto px-4 py-20"
        initial="initial"
        whileInView="animate"
        viewport={{ once: true }}
        variants={staggerChildren}
      >
        <motion.div variants={fadeInUp} className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Powerful Features, Ethical Foundation
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Built on Mozilla technologies and Anthropic AI for the perfect balance 
            of capability and privacy protection.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <motion.div key={index} variants={fadeInUp}>
              <Card className="h-full hover:shadow-lg transition-shadow border-primary/10">
                <CardHeader>
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center text-primary mb-4">
                    {feature.icon}
                  </div>
                  <CardTitle className="text-xl">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-base">
                    {feature.description}
                  </CardDescription>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </motion.section>

      {/* AI Services Comparison */}
      <motion.section 
        className="container mx-auto px-4 py-20"
        initial="initial"
        whileInView="animate"
        viewport={{ once: true }}
        variants={staggerChildren}
      >
        <motion.div variants={fadeInUp} className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Ethical AI Commitment
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            We've made a conscious choice to build with ethical AI providers 
            and reject closed, proprietary systems.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          <motion.div variants={fadeInUp}>
            <Card className="h-full border-destructive/20 bg-destructive/5">
              <CardHeader>
                <CardTitle className="flex items-center text-destructive">
                  <XCircle className="h-5 w-5 mr-2" />
                  Blocked Services
                </CardTitle>
                <CardDescription>
                  Services we explicitly reject for ethical reasons
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {blockedServices.map((service, index) => (
                    <li key={index} className="flex items-center text-destructive">
                      <XCircle className="h-4 w-4 mr-2" />
                      {service}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div variants={fadeInUp}>
            <Card className="h-full border-accent/20 bg-accent/5">
              <CardHeader>
                <CardTitle className="flex items-center text-accent">
                  <CheckCircle className="h-5 w-5 mr-2" />
                  Trusted Partners
                </CardTitle>
                <CardDescription>
                  Ethical AI services that power Voxy
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {allowedServices.map((service, index) => (
                    <li key={index} className="flex items-center text-accent">
                      <CheckCircle className="h-4 w-4 mr-2" />
                      {service}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </motion.section>

      {/* Privacy Section */}
      <motion.section 
        className="container mx-auto px-4 py-20"
        initial="initial"
        whileInView="animate"
        viewport={{ once: true }}
        variants={staggerChildren}
      >
        <motion.div variants={fadeInUp}>
          <Card className="max-w-4xl mx-auto border-primary/20 bg-primary/5">
            <CardContent className="p-12 text-center">
              <Lock className="h-16 w-16 text-primary mx-auto mb-6" />
              <h2 className="text-3xl font-bold mb-4">Your Privacy is Our Priority</h2>
              <p className="text-lg text-muted-foreground mb-6">
                Choose between cloud processing with Anthropic's secure infrastructure 
                or completely local processing using open-source models. Your data, your choice.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Badge variant="outline" className="text-sm py-2 px-4">
                  <Shield className="h-4 w-4 mr-2" />
                  GDPR Compliant
                </Badge>
                <Badge variant="outline" className="text-sm py-2 px-4">
                  <Lock className="h-4 w-4 mr-2" />
                  Local Processing Available
                </Badge>
                <Badge variant="outline" className="text-sm py-2 px-4">
                  <Heart className="h-4 w-4 mr-2" />
                  Open Source
                </Badge>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </motion.section>

      {/* CTA Section */}
      <motion.section 
        className="container mx-auto px-4 py-20 text-center"
        initial="initial"
        whileInView="animate"
        viewport={{ once: true }}
        variants={fadeInUp}
      >
        <h2 className="text-3xl md:text-4xl font-bold mb-4">
          Ready to Transform Your Content?
        </h2>
        <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
          Join the future of ethical AI-powered content creation. 
          Start converting your documents into engaging podcasts today.
        </p>
        <Button 
          size="lg" 
          className="text-lg px-8 py-6"
          onClick={() => navigate('/dashboard')}
        >
          Get Started Free
          <ArrowRight className="ml-2 h-5 w-5" />
        </Button>
      </motion.section>

      {/* Footer */}
      <footer className="border-t bg-muted/30 py-12">
        <div className="container mx-auto px-4 text-center">
          <p className="text-muted-foreground mb-4">
            Vibed with{' '}
            <a 
              href="https://soapbox.pub/mkstack" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-primary hover:underline"
            >
              MKStack
            </a>
          </p>
          <p className="text-sm text-muted-foreground">
            Built entirely through AI-driven development • Powered by Anthropic Claude & Mozilla Technologies
          </p>
        </div>
      </footer>
    </div>
  );
}