import { useCallback, useState } from 'react';
import { useDropzone } from 'react-dropzone';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  Upload, 
  FileText, 
  File, 
  X, 
  CheckCircle, 
  AlertCircle,
  Mic,
  Globe
} from 'lucide-react';
import { useVoxyStore, type Document } from '@/store/useVoxyStore';
import { cn } from '@/lib/utils';

interface FileUploaderProps {
  projectId: string;
  className?: string;
}

interface UploadingFile {
  file: File;
  progress: number;
  status: 'uploading' | 'processing' | 'complete' | 'error';
  error?: string;
}

export function FileUploader({ projectId, className }: FileUploaderProps) {
  const { addDocument } = useVoxyStore();
  const [uploadingFiles, setUploadingFiles] = useState<UploadingFile[]>([]);

  const processFile = useCallback(async (file: File) => {
    try {
      // Simulate upload progress
      for (let progress = 0; progress <= 100; progress += 10) {
        await new Promise(resolve => setTimeout(resolve, 100));
        setUploadingFiles(prev => prev.map((upload) => 
          upload.file === file ? { ...upload, progress } : upload
        ));
      }

      // Change to processing status
      setUploadingFiles(prev => prev.map(upload => 
        upload.file === file ? { ...upload, status: 'processing', progress: 0 } : upload
      ));

      // Simulate processing
      for (let progress = 0; progress <= 100; progress += 20) {
        await new Promise(resolve => setTimeout(resolve, 200));
        setUploadingFiles(prev => prev.map(upload => 
          upload.file === file ? { ...upload, progress } : upload
        ));
      }

      // Extract text content (simulated)
      const content = await extractTextContent(file);

      // Create document
      const document: Document = {
        id: crypto.randomUUID(),
        name: file.name,
        type: file.type || getFileTypeFromName(file.name),
        size: file.size,
        content,
        uploadedAt: new Date()
      };

      addDocument(projectId, document);

      // Mark as complete
      setUploadingFiles(prev => prev.map(upload => 
        upload.file === file ? { ...upload, status: 'complete', progress: 100 } : upload
      ));

      // Remove from list after delay
      setTimeout(() => {
        setUploadingFiles(prev => prev.filter(upload => upload.file !== file));
      }, 2000);

    } catch (error) {
      setUploadingFiles(prev => prev.map(upload => 
        upload.file === file ? { 
          ...upload, 
          status: 'error', 
          error: error instanceof Error ? error.message : 'Processing failed'
        } : upload
      ));
    }
  }, [addDocument, projectId]);

  const onDrop = useCallback((acceptedFiles: File[]) => {
    const newUploads: UploadingFile[] = acceptedFiles.map(file => ({
      file,
      progress: 0,
      status: 'uploading'
    }));

    setUploadingFiles(prev => [...prev, ...newUploads]);

    // Simulate file processing
    acceptedFiles.forEach((file) => {
      processFile(file);
    });
  }, [processFile]);

  const extractTextContent = async (file: File): Promise<string> => {
    // Simulate text extraction based on file type
    const fileType = file.type || getFileTypeFromName(file.name);
    
    if (fileType.includes('text') || file.name.endsWith('.md')) {
      return await file.text();
    }
    
    if (fileType.includes('audio')) {
      // Simulate Mozilla DeepSpeech transcription
      return `[Transcribed from ${file.name}]\n\nThis is simulated transcription content from Mozilla DeepSpeech. In a real implementation, this would contain the actual transcribed text from the audio file.`;
    }
    
    // For other file types, simulate extraction
    return `[Extracted from ${file.name}]\n\nThis is simulated extracted content. In a real implementation, this would contain the actual text extracted from the document using appropriate parsers for PDF, DOCX, etc.`;
  };

  const getFileTypeFromName = (name: string): string => {
    const extension = name.split('.').pop()?.toLowerCase();
    switch (extension) {
      case 'pdf': return 'application/pdf';
      case 'docx': return 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';
      case 'txt': return 'text/plain';
      case 'md': return 'text/markdown';
      case 'mp3': return 'audio/mpeg';
      case 'wav': return 'audio/wav';
      case 'mp4': return 'audio/mp4';
      default: return 'application/octet-stream';
    }
  };

  const removeUpload = (file: File) => {
    setUploadingFiles(prev => prev.filter(upload => upload.file !== file));
  };

  const getFileIcon = (fileName: string) => {
    const extension = fileName.split('.').pop()?.toLowerCase();
    if (['mp3', 'wav', 'mp4', 'm4a'].includes(extension || '')) {
      return <Mic className="h-5 w-5" />;
    }
    return <FileText className="h-5 w-5" />;
  };

  const getStatusIcon = (status: UploadingFile['status']) => {
    switch (status) {
      case 'complete':
        return <CheckCircle className="h-4 w-4 text-green-600" />;
      case 'error':
        return <AlertCircle className="h-4 w-4 text-red-600" />;
      default:
        return null;
    }
  };

  const getStatusText = (upload: UploadingFile) => {
    switch (upload.status) {
      case 'uploading':
        return 'Uploading...';
      case 'processing':
        return upload.file.type.includes('audio') ? 'Transcribing with Mozilla DeepSpeech...' : 'Processing...';
      case 'complete':
        return 'Complete';
      case 'error':
        return upload.error || 'Error';
    }
  };

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'text/plain': ['.txt'],
      'text/markdown': ['.md'],
      'application/pdf': ['.pdf'],
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx'],
      'audio/mpeg': ['.mp3'],
      'audio/wav': ['.wav'],
      'audio/mp4': ['.mp4'],
      'audio/x-m4a': ['.m4a']
    },
    maxSize: 50 * 1024 * 1024, // 50MB
    multiple: true
  });

  return (
    <div className={cn('space-y-4', className)}>
      <Card 
        {...getRootProps()} 
        className={cn(
          'border-2 border-dashed transition-colors cursor-pointer',
          isDragActive ? 'border-primary bg-primary/5' : 'border-muted-foreground/25 hover:border-primary/50'
        )}
      >
        <CardContent className="p-8 text-center">
          <input {...getInputProps()} />
          <motion.div
            animate={isDragActive ? { scale: 1.05 } : { scale: 1 }}
            transition={{ duration: 0.2 }}
          >
            <Upload className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">
              {isDragActive ? 'Drop files here' : 'Upload your documents'}
            </h3>
            <p className="text-muted-foreground mb-4">
              Drag and drop files here, or click to browse
            </p>
            <div className="flex flex-wrap justify-center gap-2 mb-4">
              <Badge variant="outline">PDF</Badge>
              <Badge variant="outline">DOCX</Badge>
              <Badge variant="outline">TXT</Badge>
              <Badge variant="outline">MD</Badge>
              <Badge variant="outline" className="bg-accent/10 border-accent">
                <Mic className="h-3 w-3 mr-1" />
                Audio (MP3, WAV)
              </Badge>
            </div>
            <p className="text-xs text-muted-foreground">
              Maximum file size: 50MB • Audio files will be transcribed with Mozilla DeepSpeech
            </p>
          </motion.div>
        </CardContent>
      </Card>

      {/* Upload Progress */}
      <AnimatePresence>
        {uploadingFiles.map((upload) => (
          <motion.div
            key={upload.file.name}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3 }}
          >
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center space-x-3">
                    {getFileIcon(upload.file.name)}
                    <div>
                      <p className="font-medium text-sm">{upload.file.name}</p>
                      <p className="text-xs text-muted-foreground">
                        {(upload.file.size / 1024 / 1024).toFixed(1)} MB
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    {getStatusIcon(upload.status)}
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => removeUpload(upload.file)}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between text-xs">
                    <span>{getStatusText(upload)}</span>
                    <span>{upload.progress}%</span>
                  </div>
                  <Progress 
                    value={upload.progress} 
                    className={cn(
                      'h-2',
                      upload.status === 'error' && 'bg-red-100',
                      upload.status === 'complete' && 'bg-green-100'
                    )}
                  />
                </div>

                {upload.file.type.includes('audio') && upload.status === 'processing' && (
                  <div className="mt-2 flex items-center text-xs text-muted-foreground">
                    <Globe className="h-3 w-3 mr-1" />
                    Using Mozilla DeepSpeech for privacy-first transcription
                  </div>
                )}
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}