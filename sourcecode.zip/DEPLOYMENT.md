# Voxy Deployment Guide

## 🎙️ AI-Powered Podcast Generation Platform
**Built entirely through AI-driven development using Anthropic Claude & Mozilla Technologies**

---

## Quick Start

### Prerequisites
- Docker & Docker Compose
- 4GB+ RAM
- 10GB+ disk space
- Anthropic API key

### 1. Clone and Configure

```bash
git clone <repository-url>
cd voxy
cp .env.example .env
```

### 2. Configure Environment

Edit `.env` file:
```bash
# REQUIRED: Add your Anthropic API key
ANTHROPIC_API_KEY=your_anthropic_api_key_here

# REQUIRED: Set secure passwords
DB_PASSWORD=your_secure_database_password
SECRET_KEY=your_super_secret_key_change_this
```

### 3. Deploy

```bash
# Make deployment script executable
chmod +x deploy.sh

# Deploy full stack
./deploy.sh deploy
```

### 4. Access

- **Frontend**: http://localhost:3000
- **Backend API**: http://localhost:8000
- **API Docs**: http://localhost:8000/api/docs
- **Mozilla Services**: http://localhost:8001

---

## Architecture Overview

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Frontend      │    │   Backend API   │    │   AI Services   │
│   (React/TS)    │◄──►│   (FastAPI)     │◄──►│ Claude/Mozilla  │
└─────────────────┘    └─────────────────┘    └─────────────────┘
         │                       │                       │
         ▼                       ▼                       ▼
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│ Mozilla STT/TTS │    │   Database      │    │   Vector DB     │
│ Common Voice DB │    │   (PostgreSQL)  │    │   (Qdrant)      │
└─────────────────┘    └─────────────────┘    └─────────────────┘
```

## Services

| Service | Port | Description |
|---------|------|-------------|
| Frontend | 3000 | React application |
| Backend | 8000 | FastAPI server |
| Mozilla Services | 8001 | DeepSpeech & TTS |
| PostgreSQL | 5432 | Main database |
| Redis | 6379 | Cache & jobs |
| Qdrant | 6333 | Vector database |
| Nginx | 80/443 | Reverse proxy |

---

## Configuration Options

### Processing Modes

1. **Cloud** (Default)
   - Anthropic Claude for text generation
   - Mozilla services for speech (local)
   - Fastest generation times

2. **Local**
   - Open-source LLMs only
   - All processing on-device
   - Maximum privacy

3. **Hybrid**
   - Balanced approach
   - User-configurable per project

### Privacy Levels

1. **Maximum**
   - All local processing
   - No external API calls
   - Slower but completely private

2. **Balanced** (Default)
   - Secure cloud for text generation
   - Local speech processing
   - Good balance of speed and privacy

3. **Performance**
   - Optimized for speed
   - Still maintains privacy controls

---

## Environment Variables

### Required

```bash
# Anthropic AI (REQUIRED)
ANTHROPIC_API_KEY=your_api_key_here

# Database
DB_PASSWORD=secure_password

# Security
SECRET_KEY=long_random_string
```

### Optional

```bash
# GPU acceleration for Mozilla TTS
ENABLE_GPU=false

# Custom domains for production
ALLOWED_ORIGINS=https://yourdomain.com
ALLOWED_HOSTS=yourdomain.com

# Monitoring
SENTRY_DSN=your_sentry_dsn
ENABLE_METRICS=true
```

### Privacy & Security (Always Enabled)

```bash
# These cannot be disabled
BLOCK_OPENAI=true
OPENAI_BLOCKER_STRICT=true
DEFAULT_PRIVACY_MODE=balanced
ENABLE_LOCAL_PROCESSING=true
```

---

## Deployment Commands

```bash
# Full deployment
./deploy.sh deploy

# Update existing deployment
./deploy.sh update

# Create backup
./deploy.sh backup

# View logs
./deploy.sh logs [service_name]

# Check status
./deploy.sh status

# Health check
./deploy.sh health

# Stop services
./deploy.sh stop

# Restart services
./deploy.sh restart
```

---

## Production Deployment

### 1. Domain Configuration

Update `.env`:
```bash
ALLOWED_ORIGINS=https://yourdomain.com
ALLOWED_HOSTS=yourdomain.com
ENVIRONMENT=production
DEBUG=false
```

### 2. SSL Configuration

Place SSL certificates in `nginx/ssl/`:
```
nginx/ssl/
├── cert.pem
└── key.pem
```

Uncomment HTTPS server block in `nginx/nginx.conf`.

### 3. Resource Requirements

**Minimum:**
- 4 CPU cores
- 8GB RAM
- 50GB disk space

**Recommended:**
- 8 CPU cores
- 16GB RAM
- 100GB SSD
- GPU for Mozilla TTS (optional)

### 4. Monitoring

Enable monitoring services:
```bash
docker-compose --profile monitoring up -d
```

Access:
- **Prometheus**: http://localhost:9090
- **Grafana**: http://localhost:3001

---

## Security Features

### OpenAI Blocking
- **Strict enforcement** at multiple levels
- Code scanning for OpenAI references
- Runtime blocking of OpenAI domains
- Cannot be disabled

### Privacy Protection
- Local processing options
- Encrypted data storage
- GDPR compliance
- User data export/deletion

### Authentication
- JWT tokens
- Bcrypt password hashing
- Rate limiting
- Session management

---

## Troubleshooting

### Common Issues

**1. Anthropic API Key Error**
```bash
# Check if API key is set
grep ANTHROPIC_API_KEY .env

# Test API key
curl -H "x-api-key: $ANTHROPIC_API_KEY" https://api.anthropic.com/v1/messages
```

**2. Mozilla Models Not Found**
```bash
# Download models manually
./deploy.sh download-models

# Check model directory
ls -la ./data/models/deepspeech/
```

**3. Database Connection Issues**
```bash
# Check database status
docker-compose exec postgres pg_isready -U voxy

# Reset database
docker-compose down -v
docker-compose up -d postgres
```

**4. Memory Issues**
```bash
# Check memory usage
docker stats

# Increase Docker memory limit
# Docker Desktop: Settings > Resources > Memory
```

### Logs

```bash
# All services
docker-compose logs -f

# Specific service
docker-compose logs -f backend

# Follow logs with timestamps
docker-compose logs -f -t backend
```

### Health Checks

```bash
# Backend health
curl http://localhost:8000/health

# Mozilla services health
curl http://localhost:8001/health

# Database health
docker-compose exec postgres pg_isready -U voxy
```

---

## Backup & Recovery

### Automated Backups

Backups are created automatically during deployments in `./backups/`.

### Manual Backup

```bash
# Create backup
./deploy.sh backup

# List backups
ls -la ./backups/
```

### Restore

```bash
# Restore from backup
./deploy.sh restore backup-name-timestamp
```

### What's Backed Up

- PostgreSQL database
- User uploaded files
- Configuration files
- Mozilla models (if downloaded)

---

## Scaling

### Horizontal Scaling

1. **Load Balancer**
   - Add multiple backend instances
   - Configure nginx upstream

2. **Database**
   - PostgreSQL read replicas
   - Connection pooling

3. **File Storage**
   - Shared storage (NFS/S3)
   - CDN for static assets

### Vertical Scaling

1. **CPU/Memory**
   - Increase Docker resource limits
   - Optimize worker processes

2. **Storage**
   - SSD for database
   - Separate volumes for different data types

---

## Monitoring & Metrics

### Built-in Monitoring

- Health check endpoints
- Structured logging
- Performance metrics
- Privacy compliance tracking

### External Monitoring

- Prometheus metrics
- Grafana dashboards
- Sentry error tracking
- Custom alerts

### Privacy-Preserving Analytics

All metrics are:
- Aggregated and anonymized
- No personal data included
- GDPR compliant
- User-controllable

---

## Support

### Documentation
- API docs: `/api/docs` (development only)
- Health status: `/health`
- Privacy report: `/api/privacy/privacy-impact-assessment`

### Community
- GitHub Issues
- Discord Community
- Email: support@voxy.ai

### Privacy
- Privacy Policy: Built-in privacy controls
- Data Export: Available in user settings
- Data Deletion: GDPR compliant

---

## License

MIT License with Mozilla compatibility.

Built entirely through AI-driven development using Anthropic Claude.
Powered by Mozilla DeepSpeech, Mozilla TTS, and Common Voice.