"""
Mozilla Services Server for Voxy
Dedicated microservice for Mozilla DeepSpeech and TTS
"""

from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.responses import FileResponse
import uvicorn
import structlog
import asyncio
import tempfile
import os
from pathlib import Path
from typing import Dict, Any, Optional

# Import Mozilla services
import deepspeech
import numpy as np
import wave
import librosa
from pydub import AudioSegment

try:
    from TTS.api import TTS
    TTS_AVAILABLE = True
except ImportError:
    TTS_AVAILABLE = False
    print("Warning: Mozilla TTS not available, falling back to espeak")

# Configure logging
structlog.configure(
    processors=[
        structlog.stdlib.filter_by_level,
        structlog.stdlib.add_logger_name,
        structlog.stdlib.add_log_level,
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.JSONRenderer()
    ],
    logger_factory=structlog.stdlib.LoggerFactory(),
    cache_logger_on_first_use=True,
)

logger = structlog.get_logger()

# FastAPI app
app = FastAPI(
    title="Mozilla Services for Voxy",
    description="Privacy-first speech recognition and synthesis using Mozilla technologies",
    version="1.0.0"
)

# Global services
deepspeech_model = None
tts_engine = None

@app.on_event("startup")
async def startup_event():
    """Initialize Mozilla services on startup"""
    global deepspeech_model, tts_engine
    
    logger.info("Initializing Mozilla services")
    
    # Initialize DeepSpeech
    try:
        model_path = "/models/deepspeech/deepspeech-0.9.3-models.pbmm"
        scorer_path = "/models/deepspeech/deepspeech-0.9.3-models.scorer"
        
        if Path(model_path).exists():
            deepspeech_model = deepspeech.Model(model_path)
            
            if Path(scorer_path).exists():
                deepspeech_model.enableExternalScorer(scorer_path)
                logger.info("DeepSpeech initialized with external scorer")
            else:
                logger.info("DeepSpeech initialized without external scorer")
        else:
            logger.warning("DeepSpeech model not found")
            
    except Exception as e:
        logger.error("Failed to initialize DeepSpeech", error=str(e))
    
    # Initialize Mozilla TTS
    try:
        if TTS_AVAILABLE:
            tts_engine = TTS(
                model_name="tts_models/en/ljspeech/tacotron2-DDC",
                vocoder_name="vocoder_models/en/ljspeech/hifigan_v2"
            )
            logger.info("Mozilla TTS initialized successfully")
        else:
            logger.info("Mozilla TTS not available, using espeak fallback")
            
    except Exception as e:
        logger.error("Failed to initialize Mozilla TTS", error=str(e))
    
    logger.info("Mozilla services startup completed")

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "services": {
            "deepspeech": {
                "available": deepspeech_model is not None,
                "model_loaded": deepspeech_model is not None
            },
            "tts": {
                "available": TTS_AVAILABLE and tts_engine is not None,
                "engine": "mozilla-tts" if TTS_AVAILABLE else "espeak"
            }
        },
        "privacy": "local_processing_only",
        "mozilla_powered": True
    }

@app.post("/transcribe")
async def transcribe_audio(file: UploadFile = File(...)):
    """Transcribe audio using Mozilla DeepSpeech"""
    
    if not deepspeech_model:
        raise HTTPException(status_code=503, detail="DeepSpeech not available")
    
    try:
        logger.info("Starting audio transcription", filename=file.filename)
        
        # Save uploaded file
        with tempfile.NamedTemporaryFile(delete=False, suffix=".wav") as temp_file:
            content = await file.read()
            temp_file.write(content)
            temp_file_path = temp_file.name
        
        # Convert to required format
        processed_path = await preprocess_audio(temp_file_path)
        
        # Read audio data
        with wave.open(processed_path, 'rb') as audio_file:
            frames = audio_file.getnframes()
            buffer = audio_file.readframes(frames)
            data16 = np.frombuffer(buffer, dtype=np.int16)
        
        # Run DeepSpeech inference
        text = deepspeech_model.stt(data16)
        metadata = deepspeech_model.sttWithMetadata(data16, num_results=1)
        
        # Extract detailed results
        timestamps = []
        confidence = 0.0
        
        if metadata.transcripts:
            transcript = metadata.transcripts[0]
            confidence = transcript.confidence
            
            for token in transcript.tokens:
                timestamps.append({
                    "text": token.text,
                    "start_time": token.start_time,
                    "duration": token.duration
                })
        
        # Cleanup
        os.unlink(temp_file_path)
        if processed_path != temp_file_path:
            os.unlink(processed_path)
        
        result = {
            "text": text,
            "confidence": confidence,
            "timestamps": timestamps,
            "language": "en-US",
            "metadata": {
                "engine": "mozilla-deepspeech",
                "model_version": "0.9.3",
                "privacy_mode": "local",
                "frames_processed": frames
            }
        }
        
        logger.info(
            "Transcription completed",
            text_length=len(text),
            confidence=confidence
        )
        
        return result
        
    except Exception as e:
        logger.error("Transcription failed", error=str(e), exc_info=True)
        raise HTTPException(status_code=500, detail=f"Transcription failed: {str(e)}")

@app.post("/synthesize")
async def synthesize_speech(
    text: str,
    voice: str = "default",
    language: str = "en-US"
):
    """Synthesize speech using Mozilla TTS"""
    
    try:
        logger.info("Starting speech synthesis", text_length=len(text), voice=voice)
        
        # Create temporary output file
        with tempfile.NamedTemporaryFile(delete=False, suffix=".wav") as temp_file:
            output_path = temp_file.name
        
        if TTS_AVAILABLE and tts_engine:
            # Use Mozilla TTS
            tts_engine.tts_to_file(text=text, file_path=output_path)
            engine_used = "mozilla-tts"
        else:
            # Fallback to espeak
            await synthesize_with_espeak(text, output_path, voice)
            engine_used = "espeak"
        
        # Get audio metadata
        audio_segment = AudioSegment.from_wav(output_path)
        duration = len(audio_segment) / 1000.0
        
        result = {
            "audio_path": output_path,
            "duration": duration,
            "sample_rate": audio_segment.frame_rate,
            "channels": audio_segment.channels,
            "metadata": {
                "engine": engine_used,
                "voice": voice,
                "language": language,
                "privacy_mode": "local",
                "text_length": len(text)
            }
        }
        
        logger.info(
            "Speech synthesis completed",
            duration=duration,
            engine=engine_used
        )
        
        return result
        
    except Exception as e:
        logger.error("Speech synthesis failed", error=str(e), exc_info=True)
        raise HTTPException(status_code=500, detail=f"Synthesis failed: {str(e)}")

@app.get("/download/{file_id}")
async def download_audio(file_id: str):
    """Download generated audio file"""
    
    # In production, implement proper file ID mapping and security
    file_path = f"/tmp/{file_id}"
    
    if not Path(file_path).exists():
        raise HTTPException(status_code=404, detail="Audio file not found")
    
    return FileResponse(
        file_path,
        media_type="audio/wav",
        filename=f"voxy_audio_{file_id}.wav"
    )

@app.get("/voices")
async def list_available_voices():
    """List available voice profiles"""
    
    voices = {
        "mozilla_tts": {
            "available": TTS_AVAILABLE and tts_engine is not None,
            "voices": [
                {
                    "id": "ljspeech",
                    "name": "LJSpeech Female",
                    "language": "en-US",
                    "gender": "female",
                    "description": "Clear, professional female voice"
                }
            ] if TTS_AVAILABLE else []
        },
        "espeak": {
            "available": True,
            "voices": [
                {
                    "id": "en+f3",
                    "name": "English Female",
                    "language": "en-US",
                    "gender": "female",
                    "description": "eSpeak female voice"
                },
                {
                    "id": "en+m3",
                    "name": "English Male",
                    "language": "en-US", 
                    "gender": "male",
                    "description": "eSpeak male voice"
                }
            ]
        }
    }
    
    return voices

async def preprocess_audio(audio_file_path: str) -> str:
    """Convert audio to format required by DeepSpeech"""
    
    try:
        # Load audio with librosa
        audio_data, sample_rate = librosa.load(audio_file_path, sr=16000, mono=True)
        
        # Convert to int16
        audio_int16 = (audio_data * 32767).astype(np.int16)
        
        # Create output file
        output_path = audio_file_path.replace('.wav', '_processed.wav')
        
        # Write WAV file
        with wave.open(output_path, 'wb') as wav_file:
            wav_file.setnchannels(1)  # Mono
            wav_file.setsampwidth(2)  # 16-bit
            wav_file.setframerate(16000)  # 16kHz
            wav_file.writeframes(audio_int16.tobytes())
        
        return output_path
        
    except Exception as e:
        logger.error("Audio preprocessing failed", error=str(e))
        raise

async def synthesize_with_espeak(text: str, output_path: str, voice: str):
    """Synthesize speech using espeak"""
    
    # Build espeak command
    cmd = ["espeak", "-w", output_path]
    
    # Voice selection
    if "female" in voice.lower():
        cmd.extend(["-v", "en+f3"])
    else:
        cmd.extend(["-v", "en+m3"])
    
    # Speech parameters
    cmd.extend(["-s", "150"])  # Speed
    cmd.extend(["-p", "50"])   # Pitch
    cmd.append(text)
    
    # Run espeak
    process = await asyncio.create_subprocess_exec(
        *cmd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE
    )
    
    stdout, stderr = await process.communicate()
    
    if process.returncode != 0:
        raise RuntimeError(f"espeak failed: {stderr.decode()}")

if __name__ == "__main__":
    uvicorn.run(
        "mozilla_server:app",
        host="0.0.0.0",
        port=8001,
        reload=False,
        log_config=None
    )