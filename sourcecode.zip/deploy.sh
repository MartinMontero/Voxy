#!/bin/bash

# Voxy Deployment Script
# AI-Powered Podcast Generation Platform
# Built with Anthropic Claude & Mozilla Technologies

set -e

echo "🎙️  Voxy Deployment Script"
echo "=================================="
echo "AI-Powered Podcast Generation Platform"
echo "Built entirely through AI-driven development"
echo ""

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
ENVIRONMENT=${ENVIRONMENT:-production}
COMPOSE_FILE=${COMPOSE_FILE:-docker-compose.yml}
BACKUP_DIR=${BACKUP_DIR:-./backups}

# Functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

check_requirements() {
    log_info "Checking deployment requirements..."
    
    # Check Docker
    if ! command -v docker &> /dev/null; then
        log_error "Docker is not installed. Please install Docker first."
        exit 1
    fi
    
    # Check Docker Compose
    if ! command -v docker-compose &> /dev/null; then
        log_error "Docker Compose is not installed. Please install Docker Compose first."
        exit 1
    fi
    
    # Check environment file
    if [ ! -f .env ]; then
        log_warning ".env file not found. Creating from template..."
        cp .env.example .env
        log_error "Please configure .env file with your settings, especially ANTHROPIC_API_KEY"
        exit 1
    fi
    
    # Check critical environment variables
    source .env
    if [ -z "$ANTHROPIC_API_KEY" ] || [ "$ANTHROPIC_API_KEY" = "your_anthropic_api_key_here" ]; then
        log_error "ANTHROPIC_API_KEY is not configured in .env file"
        exit 1
    fi
    
    log_success "Requirements check passed"
}

validate_openai_blocking() {
    log_info "Validating OpenAI blocking configuration..."
    
    source .env
    if [ "$BLOCK_OPENAI" != "true" ]; then
        log_error "OpenAI blocking is disabled. This violates Voxy's security policy."
        exit 1
    fi
    
    if [ "$OPENAI_BLOCKER_STRICT" != "true" ]; then
        log_error "Strict OpenAI blocking is disabled. This violates Voxy's security policy."
        exit 1
    fi
    
    log_success "OpenAI blocking validation passed"
}

create_directories() {
    log_info "Creating necessary directories..."
    
    mkdir -p $BACKUP_DIR
    mkdir -p ./logs
    mkdir -p ./data/uploads
    mkdir -p ./data/models
    mkdir -p ./data/common-voice
    
    log_success "Directories created"
}

backup_data() {
    if [ "$1" = "--skip-backup" ]; then
        log_warning "Skipping backup as requested"
        return
    fi
    
    log_info "Creating backup before deployment..."
    
    BACKUP_NAME="voxy-backup-$(date +%Y%m%d-%H%M%S)"
    BACKUP_PATH="$BACKUP_DIR/$BACKUP_NAME"
    
    mkdir -p "$BACKUP_PATH"
    
    # Backup database if running
    if docker-compose ps postgres | grep -q "Up"; then
        log_info "Backing up database..."
        docker-compose exec -T postgres pg_dump -U voxy voxy > "$BACKUP_PATH/database.sql"
    fi
    
    # Backup volumes
    if [ -d "./data" ]; then
        log_info "Backing up data volumes..."
        cp -r ./data "$BACKUP_PATH/"
    fi
    
    log_success "Backup created at $BACKUP_PATH"
}

download_models() {
    log_info "Downloading Mozilla models..."
    
    # Create models directory
    mkdir -p ./data/models/deepspeech
    mkdir -p ./data/models/mozilla-tts
    
    # Download DeepSpeech models if not present
    if [ ! -f "./data/models/deepspeech/deepspeech-0.9.3-models.pbmm" ]; then
        log_info "Downloading Mozilla DeepSpeech models..."
        wget -q --show-progress -O ./data/models/deepspeech/deepspeech-0.9.3-models.pbmm \
            https://github.com/mozilla/DeepSpeech/releases/download/v0.9.3/deepspeech-0.9.3-models.pbmm
        
        wget -q --show-progress -O ./data/models/deepspeech/deepspeech-0.9.3-models.scorer \
            https://github.com/mozilla/DeepSpeech/releases/download/v0.9.3/deepspeech-0.9.3-models.scorer
    fi
    
    log_success "Mozilla models ready"
}

deploy_services() {
    log_info "Deploying Voxy services..."
    
    # Pull latest images
    log_info "Pulling Docker images..."
    docker-compose -f $COMPOSE_FILE pull
    
    # Build custom images
    log_info "Building custom images..."
    docker-compose -f $COMPOSE_FILE build --no-cache
    
    # Start services
    log_info "Starting services..."
    docker-compose -f $COMPOSE_FILE up -d
    
    log_success "Services deployed"
}

wait_for_services() {
    log_info "Waiting for services to be ready..."
    
    # Wait for database
    log_info "Waiting for database..."
    timeout 60 bash -c 'until docker-compose exec postgres pg_isready -U voxy; do sleep 2; done'
    
    # Wait for backend
    log_info "Waiting for backend..."
    timeout 120 bash -c 'until curl -f http://localhost:8000/health; do sleep 5; done'
    
    # Wait for Mozilla services
    log_info "Waiting for Mozilla services..."
    timeout 120 bash -c 'until curl -f http://localhost:8001/health; do sleep 5; done'
    
    log_success "All services are ready"
}

run_migrations() {
    log_info "Running database migrations..."
    
    # Run Alembic migrations
    docker-compose exec backend alembic upgrade head
    
    log_success "Database migrations completed"
}

verify_deployment() {
    log_info "Verifying deployment..."
    
    # Check service health
    services=("frontend" "backend" "postgres" "redis" "qdrant" "mozilla-model-server")
    
    for service in "${services[@]}"; do
        if docker-compose ps $service | grep -q "Up"; then
            log_success "$service is running"
        else
            log_error "$service is not running"
            exit 1
        fi
    done
    
    # Check API endpoints
    if curl -f http://localhost:8000/health > /dev/null 2>&1; then
        log_success "Backend API is responding"
    else
        log_error "Backend API is not responding"
        exit 1
    fi
    
    if curl -f http://localhost:8001/health > /dev/null 2>&1; then
        log_success "Mozilla services are responding"
    else
        log_error "Mozilla services are not responding"
        exit 1
    fi
    
    # Check OpenAI blocking
    log_info "Verifying OpenAI blocking..."
    response=$(curl -s http://localhost:8000/health | grep -o '"openai_blocked":true' || echo "")
    if [ -n "$response" ]; then
        log_success "OpenAI blocking is active"
    else
        log_error "OpenAI blocking verification failed"
        exit 1
    fi
    
    log_success "Deployment verification completed"
}

show_status() {
    echo ""
    echo "🎉 Voxy Deployment Complete!"
    echo "=================================="
    echo ""
    echo "Services Status:"
    docker-compose ps
    echo ""
    echo "Access URLs:"
    echo "  Frontend:        http://localhost:3000"
    echo "  Backend API:     http://localhost:8000"
    echo "  API Docs:        http://localhost:8000/api/docs"
    echo "  Mozilla Services: http://localhost:8001"
    echo "  Database:        localhost:5432"
    echo ""
    echo "Privacy & Security:"
    echo "  ✅ OpenAI Blocking: ACTIVE"
    echo "  ✅ Mozilla DeepSpeech: LOCAL"
    echo "  ✅ Mozilla TTS: LOCAL"
    echo "  ✅ Anthropic Claude: SECURE CLOUD"
    echo ""
    echo "Logs:"
    echo "  docker-compose logs -f [service_name]"
    echo ""
    echo "Built entirely through AI-driven development"
    echo "Powered by Anthropic Claude & Mozilla Technologies"
}

# Main deployment flow
main() {
    case "${1:-deploy}" in
        "deploy")
            check_requirements
            validate_openai_blocking
            create_directories
            backup_data $2
            download_models
            deploy_services
            wait_for_services
            run_migrations
            verify_deployment
            show_status
            ;;
        "update")
            log_info "Updating Voxy deployment..."
            backup_data
            docker-compose -f $COMPOSE_FILE pull
            docker-compose -f $COMPOSE_FILE up -d
            wait_for_services
            run_migrations
            verify_deployment
            log_success "Update completed"
            ;;
        "backup")
            backup_data
            ;;
        "restore")
            if [ -z "$2" ]; then
                log_error "Please specify backup directory: ./deploy.sh restore backup-name"
                exit 1
            fi
            log_info "Restoring from backup: $2"
            # Restore logic here
            ;;
        "logs")
            docker-compose logs -f ${2:-}
            ;;
        "stop")
            log_info "Stopping Voxy services..."
            docker-compose down
            log_success "Services stopped"
            ;;
        "restart")
            log_info "Restarting Voxy services..."
            docker-compose restart
            log_success "Services restarted"
            ;;
        "status")
            docker-compose ps
            ;;
        "health")
            curl -s http://localhost:8000/health | jq .
            curl -s http://localhost:8001/health | jq .
            ;;
        *)
            echo "Usage: $0 {deploy|update|backup|restore|logs|stop|restart|status|health}"
            echo ""
            echo "Commands:"
            echo "  deploy    - Full deployment (default)"
            echo "  update    - Update existing deployment"
            echo "  backup    - Create backup"
            echo "  restore   - Restore from backup"
            echo "  logs      - View logs"
            echo "  stop      - Stop all services"
            echo "  restart   - Restart all services"
            echo "  status    - Show service status"
            echo "  health    - Check service health"
            echo ""
            echo "Options:"
            echo "  --skip-backup  - Skip backup during deployment"
            exit 1
            ;;
    esac
}

# Run main function with all arguments
main "$@"