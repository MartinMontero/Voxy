#!/bin/bash

# Voxy Deployment Verification Script
# Validates that the deployed application is working correctly

set -e

echo "🔍 Voxy Deployment Verification"
echo "================================"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
FRONTEND_URL=${1:-"http://localhost:3000"}
BACKEND_URL=${2:-"http://localhost:8000"}
MOZILLA_URL=${3:-"http://localhost:8001"}

log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

check_url() {
    local url=$1
    local name=$2
    local expected_status=${3:-200}
    
    log_info "Checking $name at $url"
    
    if command -v curl &> /dev/null; then
        response=$(curl -s -o /dev/null -w "%{http_code}" "$url" || echo "000")
        if [ "$response" = "$expected_status" ]; then
            log_success "$name is responding (HTTP $response)"
            return 0
        else
            log_error "$name returned HTTP $response (expected $expected_status)"
            return 1
        fi
    else
        log_warning "curl not available, skipping $name check"
        return 0
    fi
}

check_json_endpoint() {
    local url=$1
    local name=$2
    local expected_field=$3
    
    log_info "Checking $name JSON response"
    
    if command -v curl &> /dev/null && command -v jq &> /dev/null; then
        response=$(curl -s "$url" | jq -r ".$expected_field" 2>/dev/null || echo "null")
        if [ "$response" != "null" ] && [ "$response" != "" ]; then
            log_success "$name JSON response contains '$expected_field': $response"
            return 0
        else
            log_error "$name JSON response missing '$expected_field'"
            return 1
        fi
    else
        log_warning "curl or jq not available, skipping $name JSON check"
        return 0
    fi
}

check_security_headers() {
    local url=$1
    local name=$2
    
    log_info "Checking security headers for $name"
    
    if command -v curl &> /dev/null; then
        headers=$(curl -s -I "$url" 2>/dev/null || echo "")
        
        # Check for required security headers
        if echo "$headers" | grep -qi "x-frame-options"; then
            log_success "$name has X-Frame-Options header"
        else
            log_warning "$name missing X-Frame-Options header"
        fi
        
        if echo "$headers" | grep -qi "x-content-type-options"; then
            log_success "$name has X-Content-Type-Options header"
        else
            log_warning "$name missing X-Content-Type-Options header"
        fi
        
        # Check Voxy-specific headers
        if echo "$headers" | grep -qi "x-voxy-privacy"; then
            log_success "$name has Voxy privacy header"
        else
            log_warning "$name missing Voxy privacy header"
        fi
        
        if echo "$headers" | grep -qi "x-openai-blocked"; then
            log_success "$name has OpenAI blocking header"
        else
            log_warning "$name missing OpenAI blocking header"
        fi
    else
        log_warning "curl not available, skipping security header check"
    fi
}

check_openai_blocking() {
    local url=$1
    
    log_info "Verifying OpenAI blocking enforcement"
    
    if command -v curl &> /dev/null && command -v jq &> /dev/null; then
        response=$(curl -s "$url/health" | jq -r '.ai_services.openai_blocked' 2>/dev/null || echo "null")
        if [ "$response" = "true" ]; then
            log_success "OpenAI blocking is active"
        else
            log_error "OpenAI blocking verification failed"
            return 1
        fi
    else
        log_warning "Cannot verify OpenAI blocking (curl/jq not available)"
    fi
}

# Main verification process
main() {
    echo "Testing URLs:"
    echo "  Frontend: $FRONTEND_URL"
    echo "  Backend:  $BACKEND_URL"
    echo "  Mozilla:  $MOZILLA_URL"
    echo ""
    
    # Frontend checks
    echo "🌐 Frontend Verification"
    echo "------------------------"
    check_url "$FRONTEND_URL" "Frontend"
    check_security_headers "$FRONTEND_URL" "Frontend"
    echo ""
    
    # Backend checks
    echo "🔧 Backend Verification"
    echo "-----------------------"
    check_url "$BACKEND_URL/health" "Backend Health"
    check_json_endpoint "$BACKEND_URL/health" "Backend Health" "status"
    check_openai_blocking "$BACKEND_URL"
    check_security_headers "$BACKEND_URL" "Backend"
    
    # API endpoints
    check_url "$BACKEND_URL/api/docs" "API Documentation" 200
    echo ""
    
    # Mozilla services checks
    echo "🎙️ Mozilla Services Verification"
    echo "--------------------------------"
    check_url "$MOZILLA_URL/health" "Mozilla Services Health"
    check_json_endpoint "$MOZILLA_URL/health" "Mozilla Services" "mozilla_powered"
    check_url "$MOZILLA_URL/voices" "Voice Profiles API"
    echo ""
    
    # Additional API checks
    echo "📡 API Endpoints Verification"
    echo "-----------------------------"
    check_url "$BACKEND_URL/api/auth/register" "Auth Registration" 422  # Expects validation error without data
    check_url "$BACKEND_URL/api/personas/" "Personas API" 401  # Expects auth required
    check_url "$BACKEND_URL/api/privacy/openai-blocking-status" "OpenAI Blocking Status"
    echo ""
    
    # Performance checks
    echo "⚡ Performance Verification"
    echo "---------------------------"
    if command -v curl &> /dev/null; then
        frontend_time=$(curl -o /dev/null -s -w "%{time_total}" "$FRONTEND_URL" 2>/dev/null || echo "0")
        backend_time=$(curl -o /dev/null -s -w "%{time_total}" "$BACKEND_URL/health" 2>/dev/null || echo "0")
        
        log_info "Frontend response time: ${frontend_time}s"
        log_info "Backend response time: ${backend_time}s"
        
        if (( $(echo "$frontend_time < 3.0" | bc -l 2>/dev/null || echo "1") )); then
            log_success "Frontend response time is acceptable"
        else
            log_warning "Frontend response time is slow (>${frontend_time}s)"
        fi
        
        if (( $(echo "$backend_time < 1.0" | bc -l 2>/dev/null || echo "1") )); then
            log_success "Backend response time is acceptable"
        else
            log_warning "Backend response time is slow (>${backend_time}s)"
        fi
    fi
    echo ""
    
    # Final summary
    echo "📋 Verification Summary"
    echo "----------------------"
    log_success "Deployment verification completed"
    log_info "Frontend: $FRONTEND_URL"
    log_info "Backend:  $BACKEND_URL"
    log_info "Mozilla:  $MOZILLA_URL"
    echo ""
    echo "🎉 Voxy is ready for use!"
    echo ""
    echo "Next steps:"
    echo "1. Create an account at $FRONTEND_URL"
    echo "2. Upload documents and generate your first podcast"
    echo "3. Monitor logs and performance"
    echo "4. Configure custom domain (if needed)"
}

# Run verification
main "$@"